import { WebPlatformFunctions } from './WebPlatformFunctions.js';
import { RequestAuthenticator, WorkloadIdentityProvider } from '../Types.js';
export declare class BunPlatformFunctions extends WebPlatformFunctions {
    /** @override */
    createWorkloadIdentityAuthenticator(clientId: string, provider: WorkloadIdentityProvider): RequestAuthenticator;
}
