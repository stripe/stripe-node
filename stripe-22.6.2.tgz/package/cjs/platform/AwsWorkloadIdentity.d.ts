import { HttpClientInterface } from '../net/HttpClient.js';
import { RequestAuthenticator } from '../Types.js';
/** Acquires a fresh, opaque AWS web identity assertion. Never persisted. */
export type AssertionFetcher = () => Promise<string>;
/**
 * Builds an `AssertionFetcher` that calls AWS STS's `GetWebIdentityToken`,
 * using the ambient AWS credential chain (no long-lived AWS credentials are
 * ever passed to Stripe). Kept as a small standalone factory so tests can
 * substitute a fake fetcher instead of exercising real AWS SDK calls.
 */
export declare function createAwsAssertionFetcher(): AssertionFetcher;
/**
 * Builds a stateful `RequestAuthenticator` for workload identity
 * authentication: it caches the exchanged Stripe access token in memory,
 * shares a single in-flight refresh across concurrent callers, and exposes
 * `_invalidate()` so RequestSender can force a one-time re-exchange after a
 * 401. The AWS assertion fetcher is injected so tests never need real AWS
 * credentials.
 */
export declare function createWorkloadIdentityAuthenticator(clientId: string, fetchAssertion: AssertionFetcher, httpClient?: HttpClientInterface): RequestAuthenticator & {
    _isWorkloadIdentity: true;
    _invalidate: () => void;
};
