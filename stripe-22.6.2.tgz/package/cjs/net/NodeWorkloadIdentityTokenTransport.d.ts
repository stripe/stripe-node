import { WorkloadIdentityTokenResponse, WorkloadIdentityTokenTransport } from './WorkloadIdentityTokenTransport.js';
/**
 * Issues the workload identity token exchange over Node's `https` module.
 *
 * `https.request` never follows redirects, so a 3xx response is returned to the
 * caller as-is rather than replaying the assertion against another origin. The
 * destination is fixed and no user-supplied agent is used, so TLS always
 * authenticates `api.stripe.com` and the assertion is never routed through a
 * configured proxy.
 */
export declare class NodeWorkloadIdentityTokenTransport implements WorkloadIdentityTokenTransport {
    post(body: string): Promise<WorkloadIdentityTokenResponse>;
}
