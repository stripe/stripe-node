import { RequestAuthenticator, WorkloadIdentityProvider } from '../Types.js';
/**
 * Shared by every platform with npm compatibility and an ambient AWS
 * credential chain (Node.js, Deno, Bun) to resolve the 'aws' provider.
 */
export declare function createCloudCapableWorkloadIdentityAuthenticator(clientId: string, provider: WorkloadIdentityProvider, onUnsupported: () => RequestAuthenticator): RequestAuthenticator;
