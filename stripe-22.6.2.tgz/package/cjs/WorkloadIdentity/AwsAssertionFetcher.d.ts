import { AssertionFetcher } from './WorkloadIdentity.js';
export declare function createAwsAssertionFetcher(): AssertionFetcher;
