export type AwsCredentials = {
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken?: string;
    region: string;
};
/**
 * Resolves AWS credentials from the sources relevant to workloads running on
 * AWS compute: environment variables, the ECS/EKS container-credentials
 * endpoint, and EC2 IMDSv2. Deliberately does not consult `~/.aws` shared
 * config/credentials files, SSO, `credential_process`, or profile-based
 * assume-role chains -- those are AWS CLI/developer-workstation conveniences,
 * not workload-identity-from-cloud-hardware sources.
 */
export declare function resolveAwsCredentials(): Promise<AwsCredentials>;
