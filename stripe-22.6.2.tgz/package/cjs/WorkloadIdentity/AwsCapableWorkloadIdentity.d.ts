import { RequestAuthenticator, WorkloadIdentityProvider } from '../Types.js';
/**
 * Shared by every platform with npm compatibility and an ambient AWS
 * credential chain (Node.js, Deno, Bun) to resolve the 'aws' provider.
 * Any other provider is deferred to `onUnsupported`, so each platform
 * still falls back through its own class hierarchy (e.g. Deno/Bun through
 * WebPlatformFunctions) rather than a hardcoded message here.
 */
export declare function createAwsCapableWorkloadIdentityAuthenticator(clientId: string, provider: WorkloadIdentityProvider, onUnsupported: () => RequestAuthenticator): RequestAuthenticator;
