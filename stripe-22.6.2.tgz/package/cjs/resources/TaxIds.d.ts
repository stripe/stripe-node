import { StripeResource } from '../StripeResource.js';
import { Customer } from './Customers.js';
import { Account } from './Accounts.js';
import { Application } from './Applications.js';
import { OtherString, PaginationParams } from '../shared.js';
import { RequestOptions, Response, ApiListPromise } from '../lib.js';
export declare class TaxIdResource extends StripeResource {
    /**
     * Deletes an existing account or customer tax_id object.
     */
    del(id: string, params?: TaxIdDeleteParams, options?: RequestOptions): Promise<Response<DeletedTaxId>>;
    /**
     * Retrieves an account or customer tax_id object.
     */
    retrieve(id: string, params?: TaxIdRetrieveParams, options?: RequestOptions): Promise<Response<TaxId>>;
    /**
     * Returns a list of tax IDs.
     */
    list(params?: TaxIdListParams, options?: RequestOptions): ApiListPromise<TaxId>;
    /**
     * Creates a new account or customer tax_id object.
     */
    create(params: TaxIdCreateParams, options?: RequestOptions): Promise<Response<TaxId>>;
}
export interface TaxId {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'tax_id';
    /**
     * Two-letter ISO code representing the country of the tax ID.
     */
    country: string | null;
    /**
     * Time at which the object was created. Measured in seconds since the Unix epoch.
     */
    created: number;
    /**
     * ID of the customer.
     */
    customer: string | Customer | null;
    /**
     * ID of the Account representing the customer.
     */
    customer_account: string | null;
    /**
     * Always true for a deleted object
     */
    deleted?: void;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * The account or customer the tax ID belongs to.
     */
    owner: TaxId.Owner | null;
    /**
     * Type of the tax ID, one of `ad_nrt`, `ae_trn`, `al_tin`, `am_tin`, `ao_tin`, `ar_cuit`, `au_abn`, `au_arn`, `aw_tin`, `az_tin`, `ba_tin`, `bb_tin`, `bd_bin`, `bf_ifu`, `bg_uic`, `bh_vat`, `bj_ifu`, `bo_tin`, `br_cnpj`, `br_cpf`, `bs_tin`, `by_tin`, `ca_bn`, `ca_gst_hst`, `ca_pst_bc`, `ca_pst_mb`, `ca_pst_sk`, `ca_qst`, `cd_nif`, `ch_uid`, `ch_vat`, `cl_tin`, `cm_niu`, `cn_tin`, `co_nit`, `cr_tin`, `cv_nif`, `de_stn`, `do_rcn`, `ec_ruc`, `eg_tin`, `es_cif`, `et_tin`, `eu_oss_vat`, `eu_vat`, `fo_vat`, `gb_vat`, `ge_vat`, `gi_tin`, `gn_nif`, `hk_br`, `hr_oib`, `hu_tin`, `ic_nif`, `id_npwp`, `il_vat`, `in_gst`, `is_vat`, `it_cf`, `jp_cn`, `jp_rn`, `jp_trn`, `ke_pin`, `kg_tin`, `kh_tin`, `kr_brn`, `kz_bin`, `la_tin`, `li_uid`, `li_vat`, `lk_vat`, `ma_vat`, `md_vat`, `me_pib`, `mk_vat`, `mr_nif`, `mx_rfc`, `my_frp`, `my_itn`, `my_sst`, `ng_tin`, `no_vat`, `no_voec`, `np_pan`, `nz_gst`, `om_vat`, `pe_ruc`, `ph_tin`, `pl_nip`, `py_ruc`, `ro_tin`, `rs_pib`, `ru_inn`, `ru_kpp`, `sa_vat`, `sg_gst`, `sg_uen`, `si_tin`, `sn_ninea`, `sr_fin`, `sv_nit`, `th_vat`, `tj_tin`, `tr_tin`, `tw_vat`, `tz_vat`, `ua_vat`, `ug_tin`, `us_ein`, `uy_ruc`, `uz_tin`, `uz_vat`, `ve_rif`, `vn_tin`, `za_vat`, `zm_tin`, or `zw_tin`. Note that some legacy tax IDs have type `unknown`
     */
    type: TaxId.Type;
    /**
     * Value of the tax ID.
     */
    value: string;
    /**
     * Tax ID verification information.
     */
    verification: TaxId.Verification | null;
}
export interface DeletedTaxId {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'tax_id';
    /**
     * Always true for a deleted object
     */
    deleted: true;
}
export declare namespace TaxId {
    interface Owner {
        /**
         * The account being referenced when `type` is `account`.
         */
        account?: string | Account;
        /**
         * The Connect Application being referenced when `type` is `application`.
         */
        application?: string | Application;
        /**
         * The customer being referenced when `type` is `customer`.
         */
        customer?: string | Customer;
        /**
         * The Account representing the customer being referenced when `type` is `customer`.
         */
        customer_account: string | null;
        /**
         * Type of owner referenced.
         */
        type: Owner.Type;
    }
    type Type = 'ad_nrt' | 'ae_trn' | 'al_tin' | 'am_tin' | 'ao_tin' | 'ar_cuit' | 'au_abn' | 'au_arn' | 'aw_tin' | 'az_tin' | 'ba_tin' | 'bb_tin' | 'bd_bin' | 'bf_ifu' | 'bg_uic' | 'bh_vat' | 'bj_ifu' | 'bo_tin' | 'br_cnpj' | 'br_cpf' | 'bs_tin' | 'by_tin' | 'ca_bn' | 'ca_gst_hst' | 'ca_pst_bc' | 'ca_pst_mb' | 'ca_pst_sk' | 'ca_qst' | 'cd_nif' | 'ch_uid' | 'ch_vat' | 'cl_tin' | 'cm_niu' | 'cn_tin' | 'co_nit' | 'cr_tin' | 'cv_nif' | 'de_stn' | 'do_rcn' | 'ec_ruc' | 'eg_tin' | 'es_cif' | 'et_tin' | 'eu_oss_vat' | 'eu_vat' | 'fo_vat' | 'gb_vat' | 'ge_vat' | 'gi_tin' | 'gn_nif' | 'hk_br' | 'hr_oib' | 'hu_tin' | 'ic_nif' | 'id_npwp' | 'il_vat' | 'in_gst' | 'is_vat' | 'it_cf' | 'jp_cn' | 'jp_rn' | 'jp_trn' | 'ke_pin' | 'kg_tin' | 'kh_tin' | 'kr_brn' | 'kz_bin' | 'la_tin' | 'li_uid' | 'li_vat' | 'lk_vat' | 'ma_vat' | 'md_vat' | 'me_pib' | 'mk_vat' | 'mr_nif' | 'mx_rfc' | 'my_frp' | 'my_itn' | 'my_sst' | 'ng_tin' | 'no_vat' | 'no_voec' | 'np_pan' | 'nz_gst' | 'om_vat' | 'pe_ruc' | 'ph_tin' | 'pl_nip' | 'py_ruc' | 'ro_tin' | 'rs_pib' | 'ru_inn' | 'ru_kpp' | 'sa_vat' | 'sg_gst' | 'sg_uen' | 'si_tin' | 'sn_ninea' | 'sr_fin' | 'sv_nit' | 'th_vat' | 'tj_tin' | 'tr_tin' | 'tw_vat' | 'tz_vat' | 'ua_vat' | 'ug_tin' | 'unknown' | 'us_ein' | 'uy_ruc' | 'uz_tin' | 'uz_vat' | 've_rif' | 'vn_tin' | 'za_vat' | 'zm_tin' | 'zw_tin' | OtherString;
    interface Verification {
        /**
         * Verification status, one of `pending`, `verified`, `unverified`, or `unavailable`.
         */
        status: Verification.Status;
        /**
         * Verified address.
         */
        verified_address: string | null;
        /**
         * Verified name.
         */
        verified_name: string | null;
    }
    namespace Owner {
        type Type = 'account' | 'application' | 'customer' | 'self' | OtherString;
    }
    namespace Verification {
        type Status = 'pending' | 'unavailable' | 'unverified' | 'verified' | OtherString;
    }
}
export interface TaxIdCreateParams {
    /**
     * Type of the tax ID, one of `ad_nrt`, `ae_trn`, `al_tin`, `am_tin`, `ao_tin`, `ar_cuit`, `au_abn`, `au_arn`, `aw_tin`, `az_tin`, `ba_tin`, `bb_tin`, `bd_bin`, `bf_ifu`, `bg_uic`, `bh_vat`, `bj_ifu`, `bo_tin`, `br_cnpj`, `br_cpf`, `bs_tin`, `by_tin`, `ca_bn`, `ca_gst_hst`, `ca_pst_bc`, `ca_pst_mb`, `ca_pst_sk`, `ca_qst`, `cd_nif`, `ch_uid`, `ch_vat`, `cl_tin`, `cm_niu`, `cn_tin`, `co_nit`, `cr_tin`, `cv_nif`, `de_stn`, `do_rcn`, `ec_ruc`, `eg_tin`, `es_cif`, `et_tin`, `eu_oss_vat`, `eu_vat`, `fo_vat`, `gb_vat`, `ge_vat`, `gi_tin`, `gn_nif`, `hk_br`, `hr_oib`, `hu_tin`, `ic_nif`, `id_npwp`, `il_vat`, `in_gst`, `is_vat`, `it_cf`, `jp_cn`, `jp_rn`, `jp_trn`, `ke_pin`, `kg_tin`, `kh_tin`, `kr_brn`, `kz_bin`, `la_tin`, `li_uid`, `li_vat`, `lk_vat`, `ma_vat`, `md_vat`, `me_pib`, `mk_vat`, `mr_nif`, `mx_rfc`, `my_frp`, `my_itn`, `my_sst`, `ng_tin`, `no_vat`, `no_voec`, `np_pan`, `nz_gst`, `om_vat`, `pe_ruc`, `ph_tin`, `pl_nip`, `py_ruc`, `ro_tin`, `rs_pib`, `ru_inn`, `ru_kpp`, `sa_vat`, `sg_gst`, `sg_uen`, `si_tin`, `sn_ninea`, `sr_fin`, `sv_nit`, `th_vat`, `tj_tin`, `tr_tin`, `tw_vat`, `tz_vat`, `ua_vat`, `ug_tin`, `us_ein`, `uy_ruc`, `uz_tin`, `uz_vat`, `ve_rif`, `vn_tin`, `za_vat`, `zm_tin`, or `zw_tin`
     */
    type: TaxIdCreateParams.Type;
    /**
     * Value of the tax ID.
     */
    value: string;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * The account or customer the tax ID belongs to. Defaults to `owner[type]=self`.
     */
    owner?: TaxIdCreateParams.Owner;
}
export declare namespace TaxIdCreateParams {
    type Type = 'ad_nrt' | 'ae_trn' | 'al_tin' | 'am_tin' | 'ao_tin' | 'ar_cuit' | 'au_abn' | 'au_arn' | 'aw_tin' | 'az_tin' | 'ba_tin' | 'bb_tin' | 'bd_bin' | 'bf_ifu' | 'bg_uic' | 'bh_vat' | 'bj_ifu' | 'bo_tin' | 'br_cnpj' | 'br_cpf' | 'bs_tin' | 'by_tin' | 'ca_bn' | 'ca_gst_hst' | 'ca_pst_bc' | 'ca_pst_mb' | 'ca_pst_sk' | 'ca_qst' | 'cd_nif' | 'ch_uid' | 'ch_vat' | 'cl_tin' | 'cm_niu' | 'cn_tin' | 'co_nit' | 'cr_tin' | 'cv_nif' | 'de_stn' | 'do_rcn' | 'ec_ruc' | 'eg_tin' | 'es_cif' | 'et_tin' | 'eu_oss_vat' | 'eu_vat' | 'fo_vat' | 'gb_vat' | 'ge_vat' | 'gi_tin' | 'gn_nif' | 'hk_br' | 'hr_oib' | 'hu_tin' | 'ic_nif' | 'id_npwp' | 'il_vat' | 'in_gst' | 'is_vat' | 'it_cf' | 'jp_cn' | 'jp_rn' | 'jp_trn' | 'ke_pin' | 'kg_tin' | 'kh_tin' | 'kr_brn' | 'kz_bin' | 'la_tin' | 'li_uid' | 'li_vat' | 'lk_vat' | 'ma_vat' | 'md_vat' | 'me_pib' | 'mk_vat' | 'mr_nif' | 'mx_rfc' | 'my_frp' | 'my_itn' | 'my_sst' | 'ng_tin' | 'no_vat' | 'no_voec' | 'np_pan' | 'nz_gst' | 'om_vat' | 'pe_ruc' | 'ph_tin' | 'pl_nip' | 'py_ruc' | 'ro_tin' | 'rs_pib' | 'ru_inn' | 'ru_kpp' | 'sa_vat' | 'sg_gst' | 'sg_uen' | 'si_tin' | 'sn_ninea' | 'sr_fin' | 'sv_nit' | 'th_vat' | 'tj_tin' | 'tr_tin' | 'tw_vat' | 'tz_vat' | 'ua_vat' | 'ug_tin' | 'us_ein' | 'uy_ruc' | 'uz_tin' | 'uz_vat' | 've_rif' | 'vn_tin' | 'za_vat' | 'zm_tin' | 'zw_tin' | OtherString;
    interface Owner {
        /**
         * Connected Account the tax ID belongs to. Required when `type=account`
         */
        account?: string;
        /**
         * Customer the tax ID belongs to. Required when `type=customer`
         */
        customer?: string;
        /**
         * ID of the Account representing the customer that the tax ID belongs to. Can be used in place of `customer` when `type=customer`
         */
        customer_account?: string;
        /**
         * Type of owner referenced.
         */
        type: Owner.Type;
    }
    namespace Owner {
        type Type = 'account' | 'application' | 'customer' | 'self' | OtherString;
    }
}
export interface TaxIdRetrieveParams {
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
}
export interface TaxIdListParams extends PaginationParams {
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * The account or customer the tax ID belongs to. Defaults to `owner[type]=self`.
     */
    owner?: TaxIdListParams.Owner;
}
export declare namespace TaxIdListParams {
    interface Owner {
        /**
         * Connected Account the tax ID belongs to. Required when `type=account`
         */
        account?: string;
        /**
         * Customer the tax ID belongs to. Required when `type=customer`
         */
        customer?: string;
        /**
         * ID of the Account representing the customer that the tax ID belongs to. Can be used in place of `customer` when `type=customer`
         */
        customer_account?: string;
        /**
         * Type of owner referenced.
         */
        type: Owner.Type;
    }
    namespace Owner {
        type Type = 'account' | 'application' | 'customer' | 'self' | OtherString;
    }
}
export interface TaxIdDeleteParams {
}
