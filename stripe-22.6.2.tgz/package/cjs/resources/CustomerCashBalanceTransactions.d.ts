import { Customer } from './Customers.js';
import { BalanceTransaction } from './BalanceTransactions.js';
import { PaymentIntent } from './PaymentIntents.js';
import { Refund } from './Refunds.js';
import { OtherString } from '../shared.js';
export interface CustomerCashBalanceTransaction {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'customer_cash_balance_transaction';
    adjusted_for_overdraft?: CustomerCashBalanceTransaction.AdjustedForOverdraft;
    applied_to_payment?: CustomerCashBalanceTransaction.AppliedToPayment;
    /**
     * Time at which the object was created. Measured in seconds since the Unix epoch.
     */
    created: number;
    /**
     * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
     */
    currency: string;
    /**
     * The customer whose available cash balance changed as a result of this transaction.
     */
    customer: string | Customer;
    /**
     * The ID of an Account representing a customer whose available cash balance changed as a result of this transaction.
     */
    customer_account: string | null;
    /**
     * The total available cash balance for the specified currency after this transaction was applied. Represented in the [smallest currency unit](https://docs.stripe.com/currencies#zero-decimal).
     */
    ending_balance: number;
    funded?: CustomerCashBalanceTransaction.Funded;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * The amount by which the cash balance changed, represented in the [smallest currency unit](https://docs.stripe.com/currencies#zero-decimal). A positive value represents funds being added to the cash balance, a negative value represents funds being removed from the cash balance.
     */
    net_amount: number;
    refunded_from_payment?: CustomerCashBalanceTransaction.RefundedFromPayment;
    transferred_to_balance?: CustomerCashBalanceTransaction.TransferredToBalance;
    /**
     * The type of the cash balance transaction. New types may be added in future. See [Customer Balance](https://docs.stripe.com/payments/customer-balance#types) to learn more about these types.
     */
    type: CustomerCashBalanceTransaction.Type;
    unapplied_from_payment?: CustomerCashBalanceTransaction.UnappliedFromPayment;
}
export declare namespace CustomerCashBalanceTransaction {
    interface AdjustedForOverdraft {
        /**
         * The [Balance Transaction](https://docs.stripe.com/api/balance_transactions/object) that corresponds to funds taken out of your Stripe balance.
         */
        balance_transaction: string | BalanceTransaction;
        /**
         * The [Cash Balance Transaction](https://docs.stripe.com/api/cash_balance_transactions/object) that brought the customer balance negative, triggering the clawback of funds.
         */
        linked_transaction: string | CustomerCashBalanceTransaction;
    }
    interface AppliedToPayment {
        /**
         * The [Payment Intent](https://docs.stripe.com/api/payment_intents/object) that funds were applied to.
         */
        payment_intent: string | PaymentIntent;
    }
    interface Funded {
        bank_transfer: Funded.BankTransfer;
    }
    interface RefundedFromPayment {
        /**
         * The [Refund](https://docs.stripe.com/api/refunds/object) that moved these funds into the customer's cash balance.
         */
        refund: string | Refund;
    }
    interface TransferredToBalance {
        /**
         * The [Balance Transaction](https://docs.stripe.com/api/balance_transactions/object) that corresponds to funds transferred to your Stripe balance.
         */
        balance_transaction: string | BalanceTransaction;
    }
    type Type = 'adjusted_for_overdraft' | 'applied_to_payment' | 'funded' | 'funding_reversed' | 'refunded_from_payment' | 'return_canceled' | 'return_initiated' | 'transferred_to_balance' | 'unapplied_from_payment' | OtherString;
    interface UnappliedFromPayment {
        /**
         * The [Payment Intent](https://docs.stripe.com/api/payment_intents/object) that funds were unapplied from.
         */
        payment_intent: string | PaymentIntent;
    }
    namespace Funded {
        interface BankTransfer {
            eu_bank_transfer?: BankTransfer.EuBankTransfer;
            gb_bank_transfer?: BankTransfer.GbBankTransfer;
            jp_bank_transfer?: BankTransfer.JpBankTransfer;
            /**
             * The user-supplied reference field on the bank transfer.
             */
            reference: string | null;
            /**
             * The funding method type used to fund the customer balance. Permitted values include: `eu_bank_transfer`, `gb_bank_transfer`, `jp_bank_transfer`, `mx_bank_transfer`, or `us_bank_transfer`.
             */
            type: BankTransfer.Type;
            us_bank_transfer?: BankTransfer.UsBankTransfer;
        }
        namespace BankTransfer {
            interface EuBankTransfer {
                /**
                 * The BIC of the bank of the sender of the funding.
                 */
                bic: string | null;
                /**
                 * The last 4 digits of the IBAN of the sender of the funding.
                 */
                iban_last4: string | null;
                /**
                 * The full name of the sender, as supplied by the sending bank.
                 */
                sender_name: string | null;
            }
            interface GbBankTransfer {
                /**
                 * The last 4 digits of the account number of the sender of the funding.
                 */
                account_number_last4: string | null;
                /**
                 * The full name of the sender, as supplied by the sending bank.
                 */
                sender_name: string | null;
                /**
                 * The sort code of the bank of the sender of the funding
                 */
                sort_code: string | null;
            }
            interface JpBankTransfer {
                /**
                 * The name of the bank of the sender of the funding.
                 */
                sender_bank: string | null;
                /**
                 * The name of the bank branch of the sender of the funding.
                 */
                sender_branch: string | null;
                /**
                 * The full name of the sender, as supplied by the sending bank.
                 */
                sender_name: string | null;
            }
            type Type = 'eu_bank_transfer' | 'gb_bank_transfer' | 'jp_bank_transfer' | 'mx_bank_transfer' | 'us_bank_transfer' | OtherString;
            interface UsBankTransfer {
                /**
                 * The banking network used for this funding.
                 */
                network?: UsBankTransfer.Network;
                /**
                 * The full name of the sender, as supplied by the sending bank.
                 */
                sender_name: string | null;
            }
            namespace UsBankTransfer {
                type Network = 'ach' | 'domestic_wire_us' | 'swift' | OtherString;
            }
        }
    }
}
