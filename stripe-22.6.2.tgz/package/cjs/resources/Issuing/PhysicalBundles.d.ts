import { StripeResource } from '../../StripeResource.js';
import { PaginationParams, OtherString } from '../../shared.js';
import { RequestOptions, ApiListPromise, Response } from '../../lib.js';
export declare class PhysicalBundleResource extends StripeResource {
    /**
     * Returns a list of physical bundle objects. The objects are sorted in descending order by creation date, with the most recently created object appearing first.
     */
    list(params?: Issuing.PhysicalBundleListParams, options?: RequestOptions): ApiListPromise<PhysicalBundle>;
    /**
     * Retrieves a physical bundle object.
     */
    retrieve(id: string, params?: Issuing.PhysicalBundleRetrieveParams, options?: RequestOptions): Promise<Response<PhysicalBundle>>;
}
export interface PhysicalBundle {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'issuing.physical_bundle';
    features: PhysicalBundle.Features;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * Friendly display name.
     */
    name: string;
    /**
     * Whether this physical bundle can be used to create cards.
     */
    status: PhysicalBundle.Status;
    /**
     * Whether this physical bundle is a standard Stripe offering or custom-made for you.
     */
    type: PhysicalBundle.Type;
}
export declare namespace PhysicalBundle {
    interface Features {
        /**
         * The policy for how to use card logo images in a card design with this physical bundle.
         */
        card_logo: Features.CardLogo;
        /**
         * The policy for how to use carrier letter text in a card design with this physical bundle.
         */
        carrier_text: Features.CarrierText;
        /**
         * The policy for how to use a second line on a card with this physical bundle.
         */
        second_line: Features.SecondLine;
    }
    type Status = 'active' | 'inactive' | 'review' | OtherString;
    type Type = 'custom' | 'standard' | OtherString;
    namespace Features {
        type CardLogo = 'optional' | 'required' | 'unsupported' | OtherString;
        type CarrierText = 'optional' | 'required' | 'unsupported' | OtherString;
        type SecondLine = 'optional' | 'required' | 'unsupported' | OtherString;
    }
}
export declare namespace Issuing {
    interface PhysicalBundleRetrieveParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
export declare namespace Issuing {
    interface PhysicalBundleListParams extends PaginationParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
        /**
         * Only return physical bundles with the given status.
         */
        status?: PhysicalBundleListParams.Status;
        /**
         * Only return physical bundles with the given type.
         */
        type?: PhysicalBundleListParams.Type;
    }
    namespace PhysicalBundleListParams {
        type Status = 'active' | 'inactive' | 'review' | OtherString;
        type Type = 'custom' | 'standard' | OtherString;
    }
}
