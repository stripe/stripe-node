import { StripeResource } from '../../StripeResource.js';
import { File } from './../Files.js';
import { Emptyable, OtherString, PaginationParams } from '../../shared.js';
import { RequestOptions, Response, ApiListPromise } from '../../lib.js';
export declare class ConfigurationResource extends StripeResource {
    /**
     * Deletes a Configuration object.
     */
    del(id: string, params?: Terminal.ConfigurationDeleteParams, options?: RequestOptions): Promise<Response<DeletedConfiguration>>;
    /**
     * Retrieves a Configuration object.
     */
    retrieve(id: string, params?: Terminal.ConfigurationRetrieveParams, options?: RequestOptions): Promise<Response<Configuration | DeletedConfiguration>>;
    /**
     * Updates a new Configuration object.
     */
    update(id: string, params?: Terminal.ConfigurationUpdateParams, options?: RequestOptions): Promise<Response<Configuration | DeletedConfiguration>>;
    /**
     * Returns a list of Configuration objects.
     */
    list(params?: Terminal.ConfigurationListParams, options?: RequestOptions): ApiListPromise<Configuration>;
    /**
     * Creates a new Configuration object.
     */
    create(params?: Terminal.ConfigurationCreateParams, options?: RequestOptions): Promise<Response<Configuration>>;
}
export interface Configuration {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'terminal.configuration';
    bbpos_wisepad3?: Configuration.BbposWisepad3;
    bbpos_wisepos_e?: Configuration.BbposWiseposE;
    cellular?: Configuration.Cellular;
    /**
     * Always true for a deleted object
     */
    deleted?: void;
    /**
     * Whether this Configuration is the default for your account
     */
    is_account_default: boolean | null;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * String indicating the name of the Configuration object, set by the user
     */
    name: string | null;
    offline?: Configuration.Offline;
    reboot_window?: Configuration.RebootWindow;
    stripe_s700?: Configuration.StripeS700;
    stripe_s710?: Configuration.StripeS710;
    tipping?: Configuration.Tipping;
    verifone_m425?: Configuration.VerifoneM425;
    verifone_p400?: Configuration.VerifoneP400;
    verifone_p630?: Configuration.VerifoneP630;
    verifone_ux700?: Configuration.VerifoneUx700;
    verifone_v660p?: Configuration.VerifoneV660p;
    wifi?: Configuration.Wifi;
}
export interface DeletedConfiguration {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'terminal.configuration';
    /**
     * Always true for a deleted object
     */
    deleted: true;
}
export declare namespace Configuration {
    interface BbposWisepad3 {
        /**
         * A File ID representing an image to display on the reader
         */
        splashscreen?: string | File;
    }
    interface BbposWiseposE {
        /**
         * A File ID representing an image to display on the reader
         */
        splashscreen?: string | File;
    }
    interface Cellular {
        /**
         * Whether a cellular-capable reader can connect to the internet over cellular.
         */
        enabled: boolean;
    }
    interface Offline {
        /**
         * Determines whether to allow transactions to be collected while reader is offline. Defaults to false.
         */
        enabled: boolean | null;
    }
    interface RebootWindow {
        /**
         * Integer between 0 to 23 that represents the end hour of the reboot time window. The value must be different than the start_hour.
         */
        end_hour: number;
        /**
         * Integer between 0 to 23 that represents the start hour of the reboot time window.
         */
        start_hour: number;
    }
    interface StripeS700 {
        /**
         * A File ID representing an image to display on the reader
         */
        splashscreen?: string | File;
    }
    interface StripeS710 {
        /**
         * A File ID representing an image to display on the reader
         */
        splashscreen?: string | File;
    }
    interface Tipping {
        aed?: Tipping.Aed;
        aud?: Tipping.Aud;
        cad?: Tipping.Cad;
        chf?: Tipping.Chf;
        czk?: Tipping.Czk;
        dkk?: Tipping.Dkk;
        eur?: Tipping.Eur;
        gbp?: Tipping.Gbp;
        gip?: Tipping.Gip;
        hkd?: Tipping.Hkd;
        huf?: Tipping.Huf;
        jpy?: Tipping.Jpy;
        mxn?: Tipping.Mxn;
        myr?: Tipping.Myr;
        nok?: Tipping.Nok;
        nzd?: Tipping.Nzd;
        pln?: Tipping.Pln;
        ron?: Tipping.Ron;
        sek?: Tipping.Sek;
        sgd?: Tipping.Sgd;
        usd?: Tipping.Usd;
    }
    interface VerifoneM425 {
        /**
         * A File ID representing an image to display on the reader
         */
        splashscreen?: string | File;
    }
    interface VerifoneP400 {
        /**
         * A File ID representing an image to display on the reader
         */
        splashscreen?: string | File;
    }
    interface VerifoneP630 {
        /**
         * A File ID representing an image to display on the reader
         */
        splashscreen?: string | File;
    }
    interface VerifoneUx700 {
        /**
         * A File ID representing an image to display on the reader
         */
        splashscreen?: string | File;
    }
    interface VerifoneV660p {
        /**
         * A File ID representing an image to display on the reader
         */
        splashscreen?: string | File;
    }
    interface Wifi {
        enterprise_eap_peap?: Wifi.EnterpriseEapPeap;
        enterprise_eap_tls?: Wifi.EnterpriseEapTls;
        personal_psk?: Wifi.PersonalPsk;
        /**
         * Security type of the WiFi network. The hash with the corresponding name contains the credentials for this security type.
         */
        type: Wifi.Type;
    }
    namespace Tipping {
        interface Aed {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Aud {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Cad {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Chf {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Czk {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Dkk {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Eur {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Gbp {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Gip {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Hkd {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Huf {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Jpy {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Mxn {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Myr {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Nok {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Nzd {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Pln {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Ron {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Sek {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Sgd {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
        interface Usd {
            /**
             * Fixed amounts displayed when collecting a tip
             */
            fixed_amounts?: Array<number> | null;
            /**
             * Percentages displayed when collecting a tip
             */
            percentages?: Array<number> | null;
            /**
             * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
             */
            smart_tip_threshold?: number;
        }
    }
    namespace Wifi {
        interface EnterpriseEapPeap {
            /**
             * A File ID representing a PEM file containing the server certificate
             */
            ca_certificate_file?: string;
            /**
             * Password for connecting to the WiFi network
             */
            password: string;
            /**
             * Name of the WiFi network
             */
            ssid: string;
            /**
             * Username for connecting to the WiFi network
             */
            username: string;
        }
        interface EnterpriseEapTls {
            /**
             * A File ID representing a PEM file containing the server certificate
             */
            ca_certificate_file?: string;
            /**
             * A File ID representing a PEM file containing the client certificate
             */
            client_certificate_file: string;
            /**
             * A File ID representing a PEM file containing the client RSA private key
             */
            private_key_file: string;
            /**
             * Password for the private key file
             */
            private_key_file_password?: string;
            /**
             * Name of the WiFi network
             */
            ssid: string;
        }
        interface PersonalPsk {
            /**
             * Password for connecting to the WiFi network
             */
            password: string;
            /**
             * Name of the WiFi network
             */
            ssid: string;
        }
        type Type = 'enterprise_eap_peap' | 'enterprise_eap_tls' | 'personal_psk' | OtherString;
    }
}
export declare namespace Terminal {
    interface ConfigurationCreateParams {
        /**
         * An object containing device type specific settings for BBPOS WisePad 3 readers.
         */
        bbpos_wisepad3?: ConfigurationCreateParams.BbposWisepad3;
        /**
         * An object containing device type specific settings for BBPOS WisePOS E readers.
         */
        bbpos_wisepos_e?: ConfigurationCreateParams.BbposWiseposE;
        /**
         * Configuration for cellular connectivity.
         */
        cellular?: Emptyable<ConfigurationCreateParams.Cellular>;
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
        /**
         * Name of the configuration
         */
        name?: string;
        /**
         * Configurations for collecting transactions offline.
         */
        offline?: Emptyable<ConfigurationCreateParams.Offline>;
        /**
         * Reboot time settings for readers. that support customized reboot time configuration.
         */
        reboot_window?: ConfigurationCreateParams.RebootWindow;
        /**
         * An object containing device type specific settings for Stripe S700 readers.
         */
        stripe_s700?: ConfigurationCreateParams.StripeS700;
        /**
         * An object containing device type specific settings for Stripe S710 readers.
         */
        stripe_s710?: ConfigurationCreateParams.StripeS710;
        /**
         * Tipping configurations for readers that support on-reader tips.
         */
        tipping?: Emptyable<ConfigurationCreateParams.Tipping>;
        /**
         * An object containing device type specific settings for Verifone M425 readers.
         */
        verifone_m425?: ConfigurationCreateParams.VerifoneM425;
        /**
         * An object containing device type specific settings for Verifone P400 readers.
         */
        verifone_p400?: ConfigurationCreateParams.VerifoneP400;
        /**
         * An object containing device type specific settings for Verifone P630 readers.
         */
        verifone_p630?: ConfigurationCreateParams.VerifoneP630;
        /**
         * An object containing device type specific settings for Verifone UX700 readers.
         */
        verifone_ux700?: ConfigurationCreateParams.VerifoneUx700;
        /**
         * An object containing device type specific settings for Verifone V660p readers.
         */
        verifone_v660p?: ConfigurationCreateParams.VerifoneV660p;
        /**
         * Configurations for connecting to a WiFi network.
         */
        wifi?: Emptyable<ConfigurationCreateParams.Wifi>;
    }
    namespace ConfigurationCreateParams {
        interface BbposWisepad3 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface BbposWiseposE {
            /**
             * A File ID representing an image to display on the reader
             */
            splashscreen?: Emptyable<string>;
        }
        interface Cellular {
            /**
             * Determines whether to allow the reader to connect to a cellular network. Defaults to false.
             */
            enabled: boolean;
        }
        interface Offline {
            /**
             * Determines whether to allow transactions to be collected while reader is offline. Defaults to false.
             */
            enabled: boolean;
        }
        interface RebootWindow {
            /**
             * Integer between 0 to 23 that represents the end hour of the reboot time window. The value must be different than the start_hour.
             */
            end_hour: number;
            /**
             * Integer between 0 to 23 that represents the start hour of the reboot time window.
             */
            start_hour: number;
        }
        interface StripeS700 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface StripeS710 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface Tipping {
            /**
             * Tipping configuration for AED
             */
            aed?: Tipping.Aed;
            /**
             * Tipping configuration for AUD
             */
            aud?: Tipping.Aud;
            /**
             * Tipping configuration for CAD
             */
            cad?: Tipping.Cad;
            /**
             * Tipping configuration for CHF
             */
            chf?: Tipping.Chf;
            /**
             * Tipping configuration for CZK
             */
            czk?: Tipping.Czk;
            /**
             * Tipping configuration for DKK
             */
            dkk?: Tipping.Dkk;
            /**
             * Tipping configuration for EUR
             */
            eur?: Tipping.Eur;
            /**
             * Tipping configuration for GBP
             */
            gbp?: Tipping.Gbp;
            /**
             * Tipping configuration for GIP
             */
            gip?: Tipping.Gip;
            /**
             * Tipping configuration for HKD
             */
            hkd?: Tipping.Hkd;
            /**
             * Tipping configuration for HUF
             */
            huf?: Tipping.Huf;
            /**
             * Tipping configuration for JPY
             */
            jpy?: Tipping.Jpy;
            /**
             * Tipping configuration for MXN
             */
            mxn?: Tipping.Mxn;
            /**
             * Tipping configuration for MYR
             */
            myr?: Tipping.Myr;
            /**
             * Tipping configuration for NOK
             */
            nok?: Tipping.Nok;
            /**
             * Tipping configuration for NZD
             */
            nzd?: Tipping.Nzd;
            /**
             * Tipping configuration for PLN
             */
            pln?: Tipping.Pln;
            /**
             * Tipping configuration for RON
             */
            ron?: Tipping.Ron;
            /**
             * Tipping configuration for SEK
             */
            sek?: Tipping.Sek;
            /**
             * Tipping configuration for SGD
             */
            sgd?: Tipping.Sgd;
            /**
             * Tipping configuration for USD
             */
            usd?: Tipping.Usd;
        }
        interface VerifoneM425 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface VerifoneP400 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface VerifoneP630 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface VerifoneUx700 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface VerifoneV660p {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface Wifi {
            /**
             * Credentials for a WPA-Enterprise WiFi network using the EAP-PEAP authentication method.
             */
            enterprise_eap_peap?: Wifi.EnterpriseEapPeap;
            /**
             * Credentials for a WPA-Enterprise WiFi network using the EAP-TLS authentication method.
             */
            enterprise_eap_tls?: Wifi.EnterpriseEapTls;
            /**
             * Credentials for a WPA-Personal WiFi network.
             */
            personal_psk?: Wifi.PersonalPsk;
            /**
             * Security type of the WiFi network. Fill out the hash with the corresponding name to provide the set of credentials for this security type.
             */
            type: Wifi.Type;
        }
        namespace Tipping {
            interface Aed {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Aud {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Cad {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Chf {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Czk {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Dkk {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Eur {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Gbp {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Gip {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Hkd {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Huf {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Jpy {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Mxn {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Myr {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Nok {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Nzd {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Pln {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Ron {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Sek {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Sgd {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Usd {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
        }
        namespace Wifi {
            interface EnterpriseEapPeap {
                /**
                 * A File ID representing a PEM file containing the server certificate
                 */
                ca_certificate_file?: string;
                /**
                 * Password for connecting to the WiFi network
                 */
                password: string;
                /**
                 * Name of the WiFi network
                 */
                ssid: string;
                /**
                 * Username for connecting to the WiFi network
                 */
                username: string;
            }
            interface EnterpriseEapTls {
                /**
                 * A File ID representing a PEM file containing the server certificate
                 */
                ca_certificate_file?: string;
                /**
                 * A File ID representing a PEM file containing the client certificate
                 */
                client_certificate_file: string;
                /**
                 * A File ID representing a PEM file containing the client RSA private key
                 */
                private_key_file: string;
                /**
                 * Password for the private key file
                 */
                private_key_file_password?: string;
                /**
                 * Name of the WiFi network
                 */
                ssid: string;
            }
            interface PersonalPsk {
                /**
                 * Password for connecting to the WiFi network
                 */
                password: string;
                /**
                 * Name of the WiFi network
                 */
                ssid: string;
            }
            type Type = 'enterprise_eap_peap' | 'enterprise_eap_tls' | 'personal_psk' | OtherString;
        }
    }
}
export declare namespace Terminal {
    interface ConfigurationRetrieveParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
export declare namespace Terminal {
    interface ConfigurationUpdateParams {
        /**
         * An object containing device type specific settings for BBPOS WisePad 3 readers.
         */
        bbpos_wisepad3?: Emptyable<ConfigurationUpdateParams.BbposWisepad3>;
        /**
         * An object containing device type specific settings for BBPOS WisePOS E readers.
         */
        bbpos_wisepos_e?: Emptyable<ConfigurationUpdateParams.BbposWiseposE>;
        /**
         * Configuration for cellular connectivity.
         */
        cellular?: Emptyable<ConfigurationUpdateParams.Cellular>;
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
        /**
         * Name of the configuration
         */
        name?: string;
        /**
         * Configurations for collecting transactions offline.
         */
        offline?: Emptyable<ConfigurationUpdateParams.Offline>;
        /**
         * Reboot time settings for readers. that support customized reboot time configuration.
         */
        reboot_window?: Emptyable<ConfigurationUpdateParams.RebootWindow>;
        /**
         * An object containing device type specific settings for Stripe S700 readers.
         */
        stripe_s700?: Emptyable<ConfigurationUpdateParams.StripeS700>;
        /**
         * An object containing device type specific settings for Stripe S710 readers.
         */
        stripe_s710?: Emptyable<ConfigurationUpdateParams.StripeS710>;
        /**
         * Tipping configurations for readers that support on-reader tips.
         */
        tipping?: Emptyable<ConfigurationUpdateParams.Tipping>;
        /**
         * An object containing device type specific settings for Verifone M425 readers.
         */
        verifone_m425?: Emptyable<ConfigurationUpdateParams.VerifoneM425>;
        /**
         * An object containing device type specific settings for Verifone P400 readers.
         */
        verifone_p400?: Emptyable<ConfigurationUpdateParams.VerifoneP400>;
        /**
         * An object containing device type specific settings for Verifone P630 readers.
         */
        verifone_p630?: Emptyable<ConfigurationUpdateParams.VerifoneP630>;
        /**
         * An object containing device type specific settings for Verifone UX700 readers.
         */
        verifone_ux700?: Emptyable<ConfigurationUpdateParams.VerifoneUx700>;
        /**
         * An object containing device type specific settings for Verifone V660p readers.
         */
        verifone_v660p?: Emptyable<ConfigurationUpdateParams.VerifoneV660p>;
        /**
         * Configurations for connecting to a WiFi network.
         */
        wifi?: Emptyable<ConfigurationUpdateParams.Wifi>;
    }
    namespace ConfigurationUpdateParams {
        interface BbposWisepad3 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface BbposWiseposE {
            /**
             * A File ID representing an image to display on the reader
             */
            splashscreen?: Emptyable<string>;
        }
        interface Cellular {
            /**
             * Determines whether to allow the reader to connect to a cellular network. Defaults to false.
             */
            enabled: boolean;
        }
        interface Offline {
            /**
             * Determines whether to allow transactions to be collected while reader is offline. Defaults to false.
             */
            enabled: boolean;
        }
        interface RebootWindow {
            /**
             * Integer between 0 to 23 that represents the end hour of the reboot time window. The value must be different than the start_hour.
             */
            end_hour: number;
            /**
             * Integer between 0 to 23 that represents the start hour of the reboot time window.
             */
            start_hour: number;
        }
        interface StripeS700 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface StripeS710 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface Tipping {
            /**
             * Tipping configuration for AED
             */
            aed?: Tipping.Aed;
            /**
             * Tipping configuration for AUD
             */
            aud?: Tipping.Aud;
            /**
             * Tipping configuration for CAD
             */
            cad?: Tipping.Cad;
            /**
             * Tipping configuration for CHF
             */
            chf?: Tipping.Chf;
            /**
             * Tipping configuration for CZK
             */
            czk?: Tipping.Czk;
            /**
             * Tipping configuration for DKK
             */
            dkk?: Tipping.Dkk;
            /**
             * Tipping configuration for EUR
             */
            eur?: Tipping.Eur;
            /**
             * Tipping configuration for GBP
             */
            gbp?: Tipping.Gbp;
            /**
             * Tipping configuration for GIP
             */
            gip?: Tipping.Gip;
            /**
             * Tipping configuration for HKD
             */
            hkd?: Tipping.Hkd;
            /**
             * Tipping configuration for HUF
             */
            huf?: Tipping.Huf;
            /**
             * Tipping configuration for JPY
             */
            jpy?: Tipping.Jpy;
            /**
             * Tipping configuration for MXN
             */
            mxn?: Tipping.Mxn;
            /**
             * Tipping configuration for MYR
             */
            myr?: Tipping.Myr;
            /**
             * Tipping configuration for NOK
             */
            nok?: Tipping.Nok;
            /**
             * Tipping configuration for NZD
             */
            nzd?: Tipping.Nzd;
            /**
             * Tipping configuration for PLN
             */
            pln?: Tipping.Pln;
            /**
             * Tipping configuration for RON
             */
            ron?: Tipping.Ron;
            /**
             * Tipping configuration for SEK
             */
            sek?: Tipping.Sek;
            /**
             * Tipping configuration for SGD
             */
            sgd?: Tipping.Sgd;
            /**
             * Tipping configuration for USD
             */
            usd?: Tipping.Usd;
        }
        interface VerifoneM425 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface VerifoneP400 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface VerifoneP630 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface VerifoneUx700 {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface VerifoneV660p {
            /**
             * A File ID representing an image you want to display on the reader.
             */
            splashscreen?: Emptyable<string>;
        }
        interface Wifi {
            /**
             * Credentials for a WPA-Enterprise WiFi network using the EAP-PEAP authentication method.
             */
            enterprise_eap_peap?: Wifi.EnterpriseEapPeap;
            /**
             * Credentials for a WPA-Enterprise WiFi network using the EAP-TLS authentication method.
             */
            enterprise_eap_tls?: Wifi.EnterpriseEapTls;
            /**
             * Credentials for a WPA-Personal WiFi network.
             */
            personal_psk?: Wifi.PersonalPsk;
            /**
             * Security type of the WiFi network. Fill out the hash with the corresponding name to provide the set of credentials for this security type.
             */
            type: Wifi.Type;
        }
        namespace Tipping {
            interface Aed {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Aud {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Cad {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Chf {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Czk {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Dkk {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Eur {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Gbp {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Gip {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Hkd {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Huf {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Jpy {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Mxn {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Myr {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Nok {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Nzd {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Pln {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Ron {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Sek {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Sgd {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
            interface Usd {
                /**
                 * Fixed amounts displayed when collecting a tip
                 */
                fixed_amounts?: Array<number>;
                /**
                 * Percentages displayed when collecting a tip
                 */
                percentages?: Array<number>;
                /**
                 * Below this amount, fixed amounts will be displayed; above it, percentages will be displayed
                 */
                smart_tip_threshold?: number;
            }
        }
        namespace Wifi {
            interface EnterpriseEapPeap {
                /**
                 * A File ID representing a PEM file containing the server certificate
                 */
                ca_certificate_file?: string;
                /**
                 * Password for connecting to the WiFi network
                 */
                password: string;
                /**
                 * Name of the WiFi network
                 */
                ssid: string;
                /**
                 * Username for connecting to the WiFi network
                 */
                username: string;
            }
            interface EnterpriseEapTls {
                /**
                 * A File ID representing a PEM file containing the server certificate
                 */
                ca_certificate_file?: string;
                /**
                 * A File ID representing a PEM file containing the client certificate
                 */
                client_certificate_file: string;
                /**
                 * A File ID representing a PEM file containing the client RSA private key
                 */
                private_key_file: string;
                /**
                 * Password for the private key file
                 */
                private_key_file_password?: string;
                /**
                 * Name of the WiFi network
                 */
                ssid: string;
            }
            interface PersonalPsk {
                /**
                 * Password for connecting to the WiFi network
                 */
                password: string;
                /**
                 * Name of the WiFi network
                 */
                ssid: string;
            }
            type Type = 'enterprise_eap_peap' | 'enterprise_eap_tls' | 'personal_psk' | OtherString;
        }
    }
}
export declare namespace Terminal {
    interface ConfigurationListParams extends PaginationParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
        /**
         * if present, only return the account default or non-default configurations.
         */
        is_account_default?: boolean;
    }
}
export declare namespace Terminal {
    interface ConfigurationDeleteParams {
    }
}
