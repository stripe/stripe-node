import { Alert } from './Alerts.js';
export interface AlertTriggered {
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'billing.alert_triggered';
    /**
     * A billing alert is a resource that notifies you when a certain usage threshold on a meter is crossed. For example, you might create a billing alert to notify you when a certain user made 100 API requests.
     */
    alert: Alert;
    /**
     * Time at which the object was created. Measured in seconds since the Unix epoch.
     */
    created: number;
    /**
     * ID of customer for which the alert triggered
     */
    customer: string;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * The value triggering the alert
     */
    value: number;
}
