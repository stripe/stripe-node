import { StripeResource } from '../../StripeResource.js';
import { Meter } from './Meters.js';
import { Customer } from './../Customers.js';
import { PaginationParams, OtherString } from '../../shared.js';
import { RequestOptions, ApiListPromise, Response } from '../../lib.js';
export declare class AlertResource extends StripeResource {
    /**
     * Lists billing active and inactive alerts
     */
    list(params?: Billing.AlertListParams, options?: RequestOptions): ApiListPromise<Alert>;
    /**
     * Creates a billing alert
     */
    create(params: Billing.AlertCreateParams, options?: RequestOptions): Promise<Response<Alert>>;
    /**
     * Retrieves a billing alert given an ID
     */
    retrieve(id: string, params?: Billing.AlertRetrieveParams, options?: RequestOptions): Promise<Response<Alert>>;
    /**
     * Reactivates this alert, allowing it to trigger again.
     */
    activate(id: string, params?: Billing.AlertActivateParams, options?: RequestOptions): Promise<Response<Alert>>;
    /**
     * Archives this alert, removing it from the list view and APIs. This is non-reversible.
     */
    archive(id: string, params?: Billing.AlertArchiveParams, options?: RequestOptions): Promise<Response<Alert>>;
    /**
     * Deactivates this alert, preventing it from triggering.
     */
    deactivate(id: string, params?: Billing.AlertDeactivateParams, options?: RequestOptions): Promise<Response<Alert>>;
}
export interface Alert {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'billing.alert';
    /**
     * Defines the type of the alert.
     */
    alert_type: 'usage_threshold';
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * Status of the alert. This can be active, inactive or archived.
     */
    status: Alert.Status | null;
    /**
     * Title of the alert.
     */
    title: string;
    /**
     * Encapsulates configuration of the alert to monitor usage on a specific [Billing Meter](https://docs.stripe.com/api/billing/meter).
     */
    usage_threshold: Alert.UsageThreshold | null;
}
export declare namespace Alert {
    type Status = 'active' | 'archived' | 'inactive' | OtherString;
    interface UsageThreshold {
        /**
         * The filters allow limiting the scope of this usage alert. You can only specify up to one filter at this time.
         */
        filters: Array<UsageThreshold.Filter> | null;
        /**
         * The value at which this alert will trigger.
         */
        gte: number;
        /**
         * The [Billing Meter](https://docs.stripe.com/api/billing/meter) ID whose usage is monitored.
         */
        meter: string | Meter;
        /**
         * Defines how the alert will behave.
         */
        recurrence: 'one_time';
    }
    namespace UsageThreshold {
        interface Filter {
            /**
             * Limit the scope of the alert to this customer ID
             */
            customer: string | Customer | null;
            type: 'customer';
        }
    }
}
export declare namespace Billing {
    interface AlertCreateParams {
        /**
         * The type of alert to create.
         */
        alert_type: 'usage_threshold';
        /**
         * The title of the alert.
         */
        title: string;
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
        /**
         * The configuration of the usage threshold.
         */
        usage_threshold?: AlertCreateParams.UsageThreshold;
    }
    namespace AlertCreateParams {
        interface UsageThreshold {
            /**
             * The filters allows limiting the scope of this usage alert. You can only specify up to one filter at this time.
             */
            filters?: Array<UsageThreshold.Filter>;
            /**
             * Defines the threshold value that triggers the alert. The value must be greater than 0.
             */
            gte: number;
            /**
             * The [Billing Meter](https://docs.stripe.com/api/billing/meter) ID whose usage is monitored.
             */
            meter: string;
            /**
             * Defines how the alert will behave.
             */
            recurrence: 'one_time';
        }
        namespace UsageThreshold {
            interface Filter {
                /**
                 * Limit the scope to this usage alert only to this customer.
                 */
                customer?: string;
                /**
                 * What type of filter is being applied to this usage alert.
                 */
                type: 'customer';
            }
        }
    }
}
export declare namespace Billing {
    interface AlertRetrieveParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
export declare namespace Billing {
    interface AlertListParams extends PaginationParams {
        /**
         * Filter results to only include this type of alert.
         */
        alert_type?: 'usage_threshold';
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
        /**
         * Filter results to only include alerts with the given meter.
         */
        meter?: string;
    }
}
export declare namespace Billing {
    interface AlertActivateParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
export declare namespace Billing {
    interface AlertArchiveParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
export declare namespace Billing {
    interface AlertDeactivateParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
