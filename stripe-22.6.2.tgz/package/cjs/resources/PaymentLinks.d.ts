import { StripeResource } from '../StripeResource.js';
import { LineItem } from './LineItems.js';
import { Application, DeletedApplication } from './Applications.js';
import { Account } from './Accounts.js';
import { TaxId, DeletedTaxId } from './TaxIds.js';
import { ShippingRate } from './ShippingRates.js';
import { MetadataParam, Decimal, OtherString, Emptyable, PaginationParams, Metadata } from '../shared.js';
import { RequestOptions, ApiListPromise, Response, ApiList } from '../lib.js';
export declare class PaymentLinkResource extends StripeResource {
    /**
     * Returns a list of your payment links.
     */
    list(params?: PaymentLinkListParams, options?: RequestOptions): ApiListPromise<PaymentLink>;
    /**
     * Creates a payment link.
     */
    create(params: PaymentLinkCreateParams, options?: RequestOptions): Promise<Response<PaymentLink>>;
    /**
     * Retrieve a payment link.
     */
    retrieve(id: string, params?: PaymentLinkRetrieveParams, options?: RequestOptions): Promise<Response<PaymentLink>>;
    /**
     * Updates a payment link.
     */
    update(id: string, params?: PaymentLinkUpdateParams, options?: RequestOptions): Promise<Response<PaymentLink>>;
    /**
     * When retrieving a payment link, there is an includable line_items property containing the first handful of those items. There is also a URL where you can retrieve the full (paginated) list of line items.
     */
    listLineItems(id: string, params?: PaymentLinkListLineItemsParams, options?: RequestOptions): ApiListPromise<LineItem>;
}
export interface PaymentLink {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'payment_link';
    /**
     * Whether the payment link's `url` is active. If `false`, customers visiting the URL will be shown a page saying that the link has been deactivated.
     */
    active: boolean;
    after_completion: PaymentLink.AfterCompletion;
    /**
     * Whether user redeemable promotion codes are enabled.
     */
    allow_promotion_codes: boolean;
    /**
     * The ID of the Connect application that created the Payment Link.
     */
    application: string | Application | DeletedApplication | null;
    /**
     * The amount of the application fee (if any) that will be requested to be applied to the payment and transferred to the application owner's Stripe account.
     */
    application_fee_amount: number | null;
    /**
     * This represents the percentage of the subscription invoice total that will be transferred to the application owner's Stripe account.
     */
    application_fee_percent: number | null;
    automatic_tax: PaymentLink.AutomaticTax;
    /**
     * Configuration for collecting the customer's billing address. Defaults to `auto`.
     */
    billing_address_collection: PaymentLink.BillingAddressCollection;
    /**
     * When set, provides configuration to gather active consent from customers.
     */
    consent_collection: PaymentLink.ConsentCollection | null;
    /**
     * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
     */
    currency: string;
    /**
     * Collect additional information from your customer using custom fields. Up to 3 fields are supported. You can't set this parameter if `ui_mode` is `custom`.
     */
    custom_fields: Array<PaymentLink.CustomField>;
    custom_text: PaymentLink.CustomText;
    /**
     * Configuration for Customer creation during checkout.
     */
    customer_creation: PaymentLink.CustomerCreation;
    /**
     * The custom message to be displayed to a customer when a payment link is no longer active.
     */
    inactive_message: string | null;
    /**
     * Configuration for creating invoice for payment mode payment links.
     */
    invoice_creation: PaymentLink.InvoiceCreation | null;
    /**
     * The line items representing what is being sold.
     */
    line_items?: ApiList<LineItem>;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * Settings for Managed Payments for this Payment Link and resulting [CheckoutSessions](https://docs.stripe.com/api/checkout/sessions/object), [PaymentIntents](https://docs.stripe.com/api/payment_intents/object), [Invoices](https://docs.stripe.com/api/invoices/object), and [Subscriptions](https://docs.stripe.com/api/subscriptions/object).
     */
    managed_payments: PaymentLink.ManagedPayments | null;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.
     */
    metadata: Metadata;
    name_collection?: PaymentLink.NameCollection;
    /**
     * The account on behalf of which to charge. See the [Connect documentation](https://support.stripe.com/questions/sending-invoices-on-behalf-of-connected-accounts) for details.
     */
    on_behalf_of: string | Account | null;
    /**
     * The optional items presented to the customer at checkout.
     */
    optional_items?: Array<PaymentLink.OptionalItem> | null;
    /**
     * Indicates the parameters to be passed to PaymentIntent creation during checkout.
     */
    payment_intent_data: PaymentLink.PaymentIntentData | null;
    /**
     * Configuration for collecting a payment method during checkout. Defaults to `always`.
     */
    payment_method_collection: PaymentLink.PaymentMethodCollection;
    /**
     * Payment-method-specific configuration.
     */
    payment_method_options: PaymentLink.PaymentMethodOptions | null;
    /**
     * The list of payment method types that customers can use. When `null`, Stripe will dynamically show relevant payment methods you've enabled in your [payment method settings](https://dashboard.stripe.com/settings/payment_methods).
     */
    payment_method_types: Array<PaymentLink.PaymentMethodType> | null;
    phone_number_collection: PaymentLink.PhoneNumberCollection;
    /**
     * Settings that restrict the usage of a payment link.
     */
    restrictions: PaymentLink.Restrictions | null;
    /**
     * Configuration for collecting the customer's shipping address.
     */
    shipping_address_collection: PaymentLink.ShippingAddressCollection | null;
    /**
     * The shipping rate options applied to the session.
     */
    shipping_options: Array<PaymentLink.ShippingOption>;
    /**
     * Indicates the type of transaction being performed which customizes relevant text on the page, such as the submit button.
     */
    submit_type: PaymentLink.SubmitType;
    /**
     * When creating a subscription, the specified configuration data will be used. There must be at least one line item with a recurring price to use `subscription_data`.
     */
    subscription_data: PaymentLink.SubscriptionData | null;
    tax_id_collection: PaymentLink.TaxIdCollection;
    /**
     * The account (if any) the payments will be attributed to for tax reporting, and where funds from each payment will be transferred to.
     */
    transfer_data: PaymentLink.TransferData | null;
    /**
     * The public URL that can be shared with customers.
     */
    url: string;
}
export declare namespace PaymentLink {
    interface AfterCompletion {
        hosted_confirmation?: AfterCompletion.HostedConfirmation;
        redirect?: AfterCompletion.Redirect;
        /**
         * The specified behavior after the purchase is complete.
         */
        type: AfterCompletion.Type;
    }
    interface AutomaticTax {
        /**
         * If `true`, tax will be calculated automatically using the customer's location.
         */
        enabled: boolean;
        /**
         * The account that's liable for tax. If set, the business address and tax registrations required to perform the tax calculation are loaded from this account. The tax transaction is returned in the report of the connected account.
         */
        liability: AutomaticTax.Liability | null;
    }
    type BillingAddressCollection = 'auto' | 'required' | OtherString;
    interface ConsentCollection {
        /**
         * Settings related to the payment method reuse text shown in the Checkout UI.
         */
        payment_method_reuse_agreement: ConsentCollection.PaymentMethodReuseAgreement | null;
        /**
         * If set to `auto`, enables the collection of customer consent for promotional communications.
         */
        promotions: ConsentCollection.Promotions | null;
        /**
         * If set to `required`, it requires cutomers to accept the terms of service before being able to pay. If set to `none`, customers won't be shown a checkbox to accept the terms of service.
         */
        terms_of_service: ConsentCollection.TermsOfService | null;
    }
    interface CustomField {
        dropdown?: CustomField.Dropdown;
        /**
         * String of your choice that your integration can use to reconcile this field. Must be unique to this field, alphanumeric, and up to 200 characters.
         */
        key: string;
        label: CustomField.Label;
        numeric?: CustomField.Numeric;
        /**
         * Whether the customer is required to complete the field before completing the Checkout Session. Defaults to `false`.
         */
        optional: boolean;
        text?: CustomField.Text;
        /**
         * The type of the field.
         */
        type: CustomField.Type;
    }
    interface CustomText {
        /**
         * Custom text that should be displayed after the payment confirmation button.
         */
        after_submit: CustomText.AfterSubmit | null;
        /**
         * Custom text that should be displayed alongside shipping address collection.
         */
        shipping_address: CustomText.ShippingAddress | null;
        /**
         * Custom text that should be displayed alongside the payment confirmation button.
         */
        submit: CustomText.Submit | null;
        /**
         * Custom text that should be displayed in place of the default terms of service agreement text.
         */
        terms_of_service_acceptance: CustomText.TermsOfServiceAcceptance | null;
    }
    type CustomerCreation = 'always' | 'if_required' | OtherString;
    interface InvoiceCreation {
        /**
         * Enable creating an invoice on successful payment.
         */
        enabled: boolean;
        /**
         * Configuration for the invoice. Default invoice values will be used if unspecified.
         */
        invoice_data: InvoiceCreation.InvoiceData | null;
    }
    interface ManagedPayments {
        /**
         * Set to `true` to enable [Managed Payments](https://docs.stripe.com/payments/managed-payments), Stripe's merchant of record solution, for this session.
         */
        enabled: boolean;
    }
    interface NameCollection {
        business?: NameCollection.Business;
        individual?: NameCollection.Individual;
    }
    interface OptionalItem {
        adjustable_quantity: OptionalItem.AdjustableQuantity | null;
        price: string;
        quantity: number;
    }
    interface PaymentIntentData {
        /**
         * Indicates when the funds will be captured from the customer's account.
         */
        capture_method: PaymentIntentData.CaptureMethod | null;
        /**
         * An arbitrary string attached to the object. Often useful for displaying to users.
         */
        description: string | null;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that will set metadata on [Payment Intents](https://docs.stripe.com/api/payment_intents) generated from this payment link.
         */
        metadata: Metadata;
        /**
         * Indicates that you intend to make future payments with the payment method collected during checkout.
         */
        setup_future_usage: PaymentIntentData.SetupFutureUsage | null;
        /**
         * For a non-card payment, information about the charge that appears on the customer's statement when this payment succeeds in creating a charge.
         */
        statement_descriptor: string | null;
        /**
         * For a card payment, information about the charge that appears on the customer's statement when this payment succeeds in creating a charge. Concatenated with the account's statement descriptor prefix to form the complete statement descriptor.
         */
        statement_descriptor_suffix: string | null;
        /**
         * A string that identifies the resulting payment as part of a group. See the PaymentIntents [use case for connected accounts](https://docs.stripe.com/connect/separate-charges-and-transfers) for details.
         */
        transfer_group: string | null;
    }
    type PaymentMethodCollection = 'always' | 'if_required' | OtherString;
    interface PaymentMethodOptions {
        /**
         * Configuration for `card` payment methods.
         */
        card: PaymentMethodOptions.Card | null;
    }
    type PaymentMethodType = 'affirm' | 'afterpay_clearpay' | 'alipay' | 'alma' | 'au_becs_debit' | 'bacs_debit' | 'bancontact' | 'billie' | 'bizum' | 'blik' | 'boleto' | 'card' | 'cashapp' | 'eps' | 'fpx' | 'giropay' | 'grabpay' | 'ideal' | 'klarna' | 'konbini' | 'link' | 'mb_way' | 'mobilepay' | 'multibanco' | 'oxxo' | 'p24' | 'pay_by_bank' | 'paynow' | 'paypal' | 'payto' | 'pix' | 'promptpay' | 'satispay' | 'sepa_debit' | 'sofort' | 'sunbit' | 'swish' | 'twint' | 'upi' | 'us_bank_account' | 'wechat_pay' | 'zip' | OtherString;
    interface PhoneNumberCollection {
        /**
         * If `true`, a phone number will be collected during checkout.
         */
        enabled: boolean;
    }
    interface Restrictions {
        completed_sessions: Restrictions.CompletedSessions;
    }
    interface ShippingAddressCollection {
        /**
         * An array of two-letter ISO country codes representing which countries Checkout should provide as options for shipping locations. Unsupported country codes: `AS, CX, CC, CU, HM, IR, KP, MH, FM, NF, MP, PW, SD, SY, UM, VI`.
         */
        allowed_countries: Array<ShippingAddressCollection.AllowedCountry>;
    }
    interface ShippingOption {
        /**
         * A non-negative integer in cents representing how much to charge.
         */
        shipping_amount: number;
        /**
         * The ID of the Shipping Rate to use for this shipping option.
         */
        shipping_rate: string | ShippingRate;
    }
    type SubmitType = 'auto' | 'book' | 'donate' | 'pay' | 'subscribe' | OtherString;
    interface SubscriptionData {
        /**
         * The subscription's description, meant to be displayable to the customer. Use this field to optionally store an explanation of the subscription for rendering in Stripe surfaces and certain local payment methods UIs.
         */
        description: string | null;
        invoice_settings: SubscriptionData.InvoiceSettings;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that will set metadata on [Subscriptions](https://docs.stripe.com/api/subscriptions) generated from this payment link.
         */
        metadata: Metadata;
        /**
         * Integer representing the number of trial period days before the customer is charged for the first time.
         */
        trial_period_days: number | null;
        /**
         * Settings related to subscription trials.
         */
        trial_settings: SubscriptionData.TrialSettings | null;
    }
    interface TaxIdCollection {
        /**
         * Indicates whether tax ID collection is enabled for the session.
         */
        enabled: boolean;
        required: TaxIdCollection.Required;
    }
    interface TransferData {
        /**
         * The amount in cents (or local equivalent) that will be transferred to the destination account. By default, the entire amount is transferred to the destination.
         */
        amount: number | null;
        /**
         * The connected account receiving the transfer.
         */
        destination: string | Account;
    }
    namespace AfterCompletion {
        interface HostedConfirmation {
            /**
             * The custom message that is displayed to the customer after the purchase is complete.
             */
            custom_message: string | null;
        }
        interface Redirect {
            /**
             * The URL the customer will be redirected to after the purchase is complete.
             */
            url: string;
        }
        type Type = 'hosted_confirmation' | 'redirect' | OtherString;
    }
    namespace AutomaticTax {
        interface Liability {
            /**
             * The connected account being referenced when `type` is `account`.
             */
            account?: string | Account;
            /**
             * Type of the account referenced.
             */
            type: Liability.Type;
        }
        namespace Liability {
            type Type = 'account' | 'self' | OtherString;
        }
    }
    namespace ConsentCollection {
        interface PaymentMethodReuseAgreement {
            /**
             * Determines the position and visibility of the payment method reuse agreement in the UI. When set to `auto`, Stripe's defaults will be used.
             *
             * When set to `hidden`, the payment method reuse agreement text will always be hidden in the UI.
             */
            position: PaymentMethodReuseAgreement.Position;
        }
        type Promotions = 'auto' | 'none' | OtherString;
        type TermsOfService = 'none' | 'required' | OtherString;
        namespace PaymentMethodReuseAgreement {
            type Position = 'auto' | 'hidden' | OtherString;
        }
    }
    namespace CustomField {
        interface Dropdown {
            /**
             * The value that pre-fills on the payment page.
             */
            default_value: string | null;
            /**
             * The options available for the customer to select. Up to 200 options allowed.
             */
            options: Array<Dropdown.Option>;
        }
        interface Label {
            /**
             * Custom text for the label, displayed to the customer. Up to 50 characters.
             */
            custom: string | null;
            /**
             * The type of the label.
             */
            type: 'custom';
        }
        interface Numeric {
            /**
             * The value that pre-fills the field on the payment page.
             */
            default_value: string | null;
            /**
             * The maximum character length constraint for the customer's input.
             */
            maximum_length: number | null;
            /**
             * The minimum character length requirement for the customer's input.
             */
            minimum_length: number | null;
        }
        interface Text {
            /**
             * The value that pre-fills the field on the payment page.
             */
            default_value: string | null;
            /**
             * The maximum character length constraint for the customer's input.
             */
            maximum_length: number | null;
            /**
             * The minimum character length requirement for the customer's input.
             */
            minimum_length: number | null;
        }
        type Type = 'dropdown' | 'numeric' | 'text' | OtherString;
        namespace Dropdown {
            interface Option {
                /**
                 * The label for the option, displayed to the customer. Up to 100 characters.
                 */
                label: string;
                /**
                 * The value for this option, not displayed to the customer, used by your integration to reconcile the option selected by the customer. Must be unique to this option, alphanumeric, and up to 100 characters.
                 */
                value: string;
            }
        }
    }
    namespace CustomText {
        interface AfterSubmit {
            /**
             * Text can be up to 1200 characters in length.
             */
            message: string;
        }
        interface ShippingAddress {
            /**
             * Text can be up to 1200 characters in length.
             */
            message: string;
        }
        interface Submit {
            /**
             * Text can be up to 1200 characters in length.
             */
            message: string;
        }
        interface TermsOfServiceAcceptance {
            /**
             * Text can be up to 1200 characters in length.
             */
            message: string;
        }
    }
    namespace InvoiceCreation {
        interface InvoiceData {
            /**
             * The account tax IDs associated with the invoice.
             */
            account_tax_ids: Array<string | TaxId | DeletedTaxId> | null;
            /**
             * A list of up to 4 custom fields to be displayed on the invoice.
             */
            custom_fields: Array<InvoiceData.CustomField> | null;
            /**
             * An arbitrary string attached to the object. Often useful for displaying to users.
             */
            description: string | null;
            /**
             * Footer to be displayed on the invoice.
             */
            footer: string | null;
            /**
             * The connected account that issues the invoice. The invoice is presented with the branding and support information of the specified account.
             */
            issuer: InvoiceData.Issuer | null;
            /**
             * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.
             */
            metadata: Metadata | null;
            /**
             * Options for invoice PDF rendering.
             */
            rendering_options: InvoiceData.RenderingOptions | null;
        }
        namespace InvoiceData {
            interface CustomField {
                /**
                 * The name of the custom field.
                 */
                name: string;
                /**
                 * The value of the custom field.
                 */
                value: string;
            }
            interface Issuer {
                /**
                 * The connected account being referenced when `type` is `account`.
                 */
                account?: string | Account;
                /**
                 * Type of the account referenced.
                 */
                type: Issuer.Type;
            }
            interface RenderingOptions {
                /**
                 * How line-item prices and amounts will be displayed with respect to tax on invoice PDFs.
                 */
                amount_tax_display: string | null;
                /**
                 * ID of the invoice rendering template to be used for the generated invoice.
                 */
                template: string | null;
            }
            namespace Issuer {
                type Type = 'account' | 'self' | OtherString;
            }
        }
    }
    namespace NameCollection {
        interface Business {
            /**
             * Indicates whether business name collection is enabled for the payment link.
             */
            enabled: boolean;
            /**
             * Whether the customer is required to complete the field before checking out. Defaults to `false`.
             */
            optional: boolean;
        }
        interface Individual {
            /**
             * Indicates whether individual name collection is enabled for the payment link.
             */
            enabled: boolean;
            /**
             * Whether the customer is required to complete the field before checking out. Defaults to `false`.
             */
            optional: boolean;
        }
    }
    namespace OptionalItem {
        interface AdjustableQuantity {
            /**
             * Set to true if the quantity can be adjusted to any non-negative integer.
             */
            enabled: boolean;
            /**
             * The maximum quantity of this item the customer can purchase. By default this value is 99.
             */
            maximum: number | null;
            /**
             * The minimum quantity of this item the customer must purchase, if they choose to purchase it. Because this item is optional, the customer will always be able to remove it from their order, even if the `minimum` configured here is greater than 0. By default this value is 0.
             */
            minimum: number | null;
        }
    }
    namespace PaymentIntentData {
        type CaptureMethod = 'automatic' | 'automatic_async' | 'manual' | OtherString;
        type SetupFutureUsage = 'off_session' | 'on_session' | OtherString;
    }
    namespace PaymentMethodOptions {
        interface Card {
            /**
             * Restrictions to apply to the card payment method. For example, you can block specific card brands.
             */
            restrictions: Card.Restrictions | null;
        }
        namespace Card {
            interface Restrictions {
                /**
                 * The card brands to block. If a customer enters or selects a card belonging to a blocked brand, they can't complete the payment.
                 */
                brands_blocked: Array<Restrictions.BrandsBlocked>;
            }
            namespace Restrictions {
                type BrandsBlocked = 'american_express' | 'discover_global_network' | 'mastercard' | 'visa' | OtherString;
            }
        }
    }
    namespace Restrictions {
        interface CompletedSessions {
            /**
             * The current number of checkout sessions that have been completed on the payment link which count towards the `completed_sessions` restriction to be met.
             */
            count: number;
            /**
             * The maximum number of checkout sessions that can be completed for the `completed_sessions` restriction to be met.
             */
            limit: number;
        }
    }
    namespace ShippingAddressCollection {
        type AllowedCountry = 'AC' | 'AD' | 'AE' | 'AF' | 'AG' | 'AI' | 'AL' | 'AM' | 'AO' | 'AQ' | 'AR' | 'AT' | 'AU' | 'AW' | 'AX' | 'AZ' | 'BA' | 'BB' | 'BD' | 'BE' | 'BF' | 'BG' | 'BH' | 'BI' | 'BJ' | 'BL' | 'BM' | 'BN' | 'BO' | 'BQ' | 'BR' | 'BS' | 'BT' | 'BV' | 'BW' | 'BY' | 'BZ' | 'CA' | 'CD' | 'CF' | 'CG' | 'CH' | 'CI' | 'CK' | 'CL' | 'CM' | 'CN' | 'CO' | 'CR' | 'CV' | 'CW' | 'CY' | 'CZ' | 'DE' | 'DJ' | 'DK' | 'DM' | 'DO' | 'DZ' | 'EC' | 'EE' | 'EG' | 'EH' | 'ER' | 'ES' | 'ET' | 'FI' | 'FJ' | 'FK' | 'FO' | 'FR' | 'GA' | 'GB' | 'GD' | 'GE' | 'GF' | 'GG' | 'GH' | 'GI' | 'GL' | 'GM' | 'GN' | 'GP' | 'GQ' | 'GR' | 'GS' | 'GT' | 'GU' | 'GW' | 'GY' | 'HK' | 'HN' | 'HR' | 'HT' | 'HU' | 'ID' | 'IE' | 'IL' | 'IM' | 'IN' | 'IO' | 'IQ' | 'IS' | 'IT' | 'JE' | 'JM' | 'JO' | 'JP' | 'KE' | 'KG' | 'KH' | 'KI' | 'KM' | 'KN' | 'KR' | 'KW' | 'KY' | 'KZ' | 'LA' | 'LB' | 'LC' | 'LI' | 'LK' | 'LR' | 'LS' | 'LT' | 'LU' | 'LV' | 'LY' | 'MA' | 'MC' | 'MD' | 'ME' | 'MF' | 'MG' | 'MK' | 'ML' | 'MM' | 'MN' | 'MO' | 'MQ' | 'MR' | 'MS' | 'MT' | 'MU' | 'MV' | 'MW' | 'MX' | 'MY' | 'MZ' | 'NA' | 'NC' | 'NE' | 'NG' | 'NI' | 'NL' | 'NO' | 'NP' | 'NR' | 'NU' | 'NZ' | 'OM' | 'PA' | 'PE' | 'PF' | 'PG' | 'PH' | 'PK' | 'PL' | 'PM' | 'PN' | 'PR' | 'PS' | 'PT' | 'PY' | 'QA' | 'RE' | 'RO' | 'RS' | 'RU' | 'RW' | 'SA' | 'SB' | 'SC' | 'SD' | 'SE' | 'SG' | 'SH' | 'SI' | 'SJ' | 'SK' | 'SL' | 'SM' | 'SN' | 'SO' | 'SR' | 'SS' | 'ST' | 'SV' | 'SX' | 'SZ' | 'TA' | 'TC' | 'TD' | 'TF' | 'TG' | 'TH' | 'TJ' | 'TK' | 'TL' | 'TM' | 'TN' | 'TO' | 'TR' | 'TT' | 'TV' | 'TW' | 'TZ' | 'UA' | 'UG' | 'US' | 'UY' | 'UZ' | 'VA' | 'VC' | 'VE' | 'VG' | 'VN' | 'VU' | 'WF' | 'WS' | 'XK' | 'YE' | 'YT' | 'ZA' | 'ZM' | 'ZW' | 'ZZ' | OtherString;
    }
    namespace SubscriptionData {
        interface InvoiceSettings {
            issuer: InvoiceSettings.Issuer;
        }
        interface TrialSettings {
            /**
             * Defines how a subscription behaves when a free trial ends.
             */
            end_behavior: TrialSettings.EndBehavior;
        }
        namespace InvoiceSettings {
            interface Issuer {
                /**
                 * The connected account being referenced when `type` is `account`.
                 */
                account?: string | Account;
                /**
                 * Type of the account referenced.
                 */
                type: Issuer.Type;
            }
            namespace Issuer {
                type Type = 'account' | 'self' | OtherString;
            }
        }
        namespace TrialSettings {
            interface EndBehavior {
                /**
                 * Indicates how the subscription should change when the trial ends if the user did not provide a payment method.
                 */
                missing_payment_method: EndBehavior.MissingPaymentMethod;
            }
            namespace EndBehavior {
                type MissingPaymentMethod = 'cancel' | 'create_invoice' | 'pause' | OtherString;
            }
        }
    }
    namespace TaxIdCollection {
        type Required = 'if_supported' | 'never' | OtherString;
    }
}
export interface PaymentLinkCreateParams {
    /**
     * The line items representing what is being sold. Each line item represents an item being sold. Up to 20 line items are supported.
     */
    line_items: Array<PaymentLinkCreateParams.LineItem>;
    /**
     * Behavior after the purchase is complete.
     */
    after_completion?: PaymentLinkCreateParams.AfterCompletion;
    /**
     * Enables user redeemable promotion codes.
     */
    allow_promotion_codes?: boolean;
    /**
     * The amount of the application fee (if any) that will be requested to be applied to the payment and transferred to the application owner's Stripe account. Can only be applied when there are no line items with recurring prices.
     */
    application_fee_amount?: number;
    /**
     * A non-negative decimal between 0 and 100, with at most two decimal places. This represents the percentage of the subscription invoice total that will be transferred to the application owner's Stripe account. There must be at least 1 line item with a recurring price to use this field.
     */
    application_fee_percent?: number;
    /**
     * Configuration for automatic tax collection.
     */
    automatic_tax?: PaymentLinkCreateParams.AutomaticTax;
    /**
     * Configuration for collecting the customer's billing address. Defaults to `auto`.
     */
    billing_address_collection?: PaymentLinkCreateParams.BillingAddressCollection;
    /**
     * Configure fields to gather active consent from customers.
     */
    consent_collection?: PaymentLinkCreateParams.ConsentCollection;
    /**
     * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies) and supported by each line item's price.
     */
    currency?: string;
    /**
     * Collect additional information from your customer using custom fields. Up to 3 fields are supported. You can't set this parameter if `ui_mode` is `custom`.
     */
    custom_fields?: Array<PaymentLinkCreateParams.CustomField>;
    /**
     * Display additional text for your customers using custom text. You can't set this parameter if `ui_mode` is `custom`.
     */
    custom_text?: PaymentLinkCreateParams.CustomText;
    /**
     * Configures whether [checkout sessions](https://docs.stripe.com/api/checkout/sessions) created by this payment link create a [Customer](https://docs.stripe.com/api/customers).
     */
    customer_creation?: PaymentLinkCreateParams.CustomerCreation;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * The custom message to be displayed to a customer when a payment link is no longer active.
     */
    inactive_message?: string;
    /**
     * Generate a post-purchase Invoice for one-time payments.
     */
    invoice_creation?: PaymentLinkCreateParams.InvoiceCreation;
    /**
     * Settings for Managed Payments for this Payment Link and resulting [CheckoutSessions](https://docs.stripe.com/api/checkout/sessions/object), [PaymentIntents](https://docs.stripe.com/api/payment_intents/object), [Invoices](https://docs.stripe.com/api/invoices/object), and [Subscriptions](https://docs.stripe.com/api/subscriptions/object).
     */
    managed_payments?: PaymentLinkCreateParams.ManagedPayments;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`. Metadata associated with this Payment Link will automatically be copied to [checkout sessions](https://docs.stripe.com/api/checkout/sessions) created by this payment link.
     */
    metadata?: MetadataParam;
    /**
     * Controls settings applied for collecting the customer's name.
     */
    name_collection?: PaymentLinkCreateParams.NameCollection;
    /**
     * The account on behalf of which to charge.
     */
    on_behalf_of?: string;
    /**
     * A list of optional items the customer can add to their order at checkout. Use this parameter to pass one-time or recurring [Prices](https://docs.stripe.com/api/prices).
     * There is a maximum of 10 optional items allowed on a payment link, and the existing limits on the number of line items allowed on a payment link apply to the combined number of line items and optional items.
     * There is a maximum of 20 combined line items and optional items.
     */
    optional_items?: Array<PaymentLinkCreateParams.OptionalItem>;
    /**
     * A subset of parameters to be passed to PaymentIntent creation for Checkout Sessions in `payment` mode.
     */
    payment_intent_data?: PaymentLinkCreateParams.PaymentIntentData;
    /**
     * Specify whether Checkout should collect a payment method. When set to `if_required`, Checkout will not collect a payment method when the total due for the session is 0.This may occur if the Checkout Session includes a free trial or a discount.
     *
     * Can only be set in `subscription` mode. Defaults to `always`.
     *
     * If you'd like information on how to collect a payment method outside of Checkout, read the guide on [configuring subscriptions with a free trial](https://docs.stripe.com/payments/checkout/free-trials).
     */
    payment_method_collection?: PaymentLinkCreateParams.PaymentMethodCollection;
    /**
     * Payment-method-specific configuration.
     */
    payment_method_options?: PaymentLinkCreateParams.PaymentMethodOptions;
    /**
     * The list of payment method types that customers can use. If no value is passed, Stripe will dynamically show relevant payment methods from your [payment method settings](https://dashboard.stripe.com/settings/payment_methods) (20+ payment methods [supported](https://docs.stripe.com/payments/payment-methods/integration-options#payment-method-product-support)).
     */
    payment_method_types?: Array<PaymentLinkCreateParams.PaymentMethodType>;
    /**
     * Controls phone number collection settings during checkout.
     *
     * We recommend that you review your privacy policy and check with your legal contacts.
     */
    phone_number_collection?: PaymentLinkCreateParams.PhoneNumberCollection;
    /**
     * Settings that restrict the usage of a payment link.
     */
    restrictions?: PaymentLinkCreateParams.Restrictions;
    /**
     * Configuration for collecting the customer's shipping address.
     */
    shipping_address_collection?: PaymentLinkCreateParams.ShippingAddressCollection;
    /**
     * The shipping rate options to apply to [checkout sessions](https://docs.stripe.com/api/checkout/sessions) created by this payment link.
     */
    shipping_options?: Array<PaymentLinkCreateParams.ShippingOption>;
    /**
     * Describes the type of transaction being performed in order to customize relevant text on the page, such as the submit button. Changing this value will also affect the hostname in the [url](https://docs.stripe.com/api/payment_links/payment_links/object#url) property (example: `donate.stripe.com`).
     */
    submit_type?: PaymentLinkCreateParams.SubmitType;
    /**
     * When creating a subscription, the specified configuration data will be used. There must be at least one line item with a recurring price to use `subscription_data`.
     */
    subscription_data?: PaymentLinkCreateParams.SubscriptionData;
    /**
     * Controls tax ID collection during checkout.
     */
    tax_id_collection?: PaymentLinkCreateParams.TaxIdCollection;
    /**
     * The account (if any) the payments will be attributed to for tax reporting, and where funds from each payment will be transferred to.
     */
    transfer_data?: PaymentLinkCreateParams.TransferData;
}
export declare namespace PaymentLinkCreateParams {
    interface LineItem {
        /**
         * When set, provides configuration for this item's quantity to be adjusted by the customer during checkout.
         */
        adjustable_quantity?: LineItem.AdjustableQuantity;
        /**
         * The ID of the [Price](https://docs.stripe.com/api/prices) or [Plan](https://docs.stripe.com/api/plans) object. One of `price` or `price_data` is required.
         */
        price?: string;
        /**
         * Data used to generate a new [Price](https://docs.stripe.com/api/prices) object inline. One of `price` or `price_data` is required.
         */
        price_data?: LineItem.PriceData;
        /**
         * The quantity of the line item being purchased.
         */
        quantity: number;
    }
    interface AfterCompletion {
        /**
         * Configuration when `type=hosted_confirmation`.
         */
        hosted_confirmation?: AfterCompletion.HostedConfirmation;
        /**
         * Configuration when `type=redirect`.
         */
        redirect?: AfterCompletion.Redirect;
        /**
         * The specified behavior after the purchase is complete. Either `redirect` or `hosted_confirmation`.
         */
        type: AfterCompletion.Type;
    }
    interface AutomaticTax {
        /**
         * Set to `true` to [calculate tax automatically](https://docs.stripe.com/tax) using the customer's location.
         *
         * Enabling this parameter causes the payment link to collect any billing address information necessary for tax calculation.
         */
        enabled: boolean;
        /**
         * The account that's liable for tax. If set, the business address and tax registrations required to perform the tax calculation are loaded from this account. The tax transaction is returned in the report of the connected account.
         */
        liability?: AutomaticTax.Liability;
    }
    type BillingAddressCollection = 'auto' | 'required' | OtherString;
    interface ConsentCollection {
        /**
         * Determines the display of payment method reuse agreement text in the UI. If set to `hidden`, it will hide legal text related to the reuse of a payment method.
         */
        payment_method_reuse_agreement?: ConsentCollection.PaymentMethodReuseAgreement;
        /**
         * If set to `auto`, enables the collection of customer consent for promotional communications. The Checkout
         * Session will determine whether to display an option to opt into promotional communication
         * from the merchant depending on the customer's locale. Only available to US merchants and US customers.
         */
        promotions?: ConsentCollection.Promotions;
        /**
         * If set to `required`, it requires customers to check a terms of service checkbox before being able to pay.
         * There must be a valid terms of service URL set in your [Dashboard settings](https://dashboard.stripe.com/settings/public).
         */
        terms_of_service?: ConsentCollection.TermsOfService;
    }
    interface CustomField {
        /**
         * Configuration for `type=dropdown` fields.
         */
        dropdown?: CustomField.Dropdown;
        /**
         * String of your choice that your integration can use to reconcile this field. Must be unique to this field, alphanumeric, and up to 200 characters.
         */
        key: string;
        /**
         * The label for the field, displayed to the customer.
         */
        label: CustomField.Label;
        /**
         * Configuration for `type=numeric` fields.
         */
        numeric?: CustomField.Numeric;
        /**
         * Whether the customer is required to complete the field before completing the Checkout Session. Defaults to `false`.
         */
        optional?: boolean;
        /**
         * Configuration for `type=text` fields.
         */
        text?: CustomField.Text;
        /**
         * The type of the field.
         */
        type: CustomField.Type;
    }
    interface CustomText {
        /**
         * Custom text that should be displayed after the payment confirmation button.
         */
        after_submit?: Emptyable<CustomText.AfterSubmit>;
        /**
         * Custom text that should be displayed alongside shipping address collection.
         */
        shipping_address?: Emptyable<CustomText.ShippingAddress>;
        /**
         * Custom text that should be displayed alongside the payment confirmation button.
         */
        submit?: Emptyable<CustomText.Submit>;
        /**
         * Custom text that should be displayed in place of the default terms of service agreement text.
         */
        terms_of_service_acceptance?: Emptyable<CustomText.TermsOfServiceAcceptance>;
    }
    type CustomerCreation = 'always' | 'if_required' | OtherString;
    interface InvoiceCreation {
        /**
         * Whether the feature is enabled
         */
        enabled: boolean;
        /**
         * Invoice PDF configuration.
         */
        invoice_data?: InvoiceCreation.InvoiceData;
    }
    interface ManagedPayments {
        /**
         * Set to `true` to enable [Managed Payments](https://docs.stripe.com/payments/managed-payments), Stripe's merchant of record solution, for this session.
         */
        enabled?: boolean;
    }
    interface NameCollection {
        /**
         * Controls settings applied for collecting the customer's business name.
         */
        business?: NameCollection.Business;
        /**
         * Controls settings applied for collecting the customer's individual name.
         */
        individual?: NameCollection.Individual;
    }
    interface OptionalItem {
        /**
         * When set, provides configuration for the customer to adjust the quantity of the line item created when a customer chooses to add this optional item to their order.
         */
        adjustable_quantity?: OptionalItem.AdjustableQuantity;
        /**
         * The ID of the [Price](https://docs.stripe.com/api/prices) or [Plan](https://docs.stripe.com/api/plans) object.
         */
        price: string;
        /**
         * The initial quantity of the line item created when a customer chooses to add this optional item to their order.
         */
        quantity: number;
    }
    interface PaymentIntentData {
        /**
         * Controls when the funds will be captured from the customer's account.
         */
        capture_method?: PaymentIntentData.CaptureMethod;
        /**
         * An arbitrary string attached to the object. Often useful for displaying to users.
         */
        description?: string;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that will declaratively set metadata on [Payment Intents](https://docs.stripe.com/api/payment_intents) generated from this payment link. Unlike object-level metadata, this field is declarative. Updates will clear prior values.
         */
        metadata?: MetadataParam;
        /**
         * Indicates that you intend to [make future payments](https://docs.stripe.com/payments/payment-intents#future-usage) with the payment method collected by this Checkout Session.
         *
         * When setting this to `on_session`, Checkout will show a notice to the customer that their payment details will be saved.
         *
         * When setting this to `off_session`, Checkout will show a notice to the customer that their payment details will be saved and used for future payments.
         *
         * If a Customer has been provided or Checkout creates a new Customer,Checkout will attach the payment method to the Customer.
         *
         * If Checkout does not create a Customer, the payment method is not attached to a Customer. To reuse the payment method, you can retrieve it from the Checkout Session's PaymentIntent.
         *
         * When processing card payments, Checkout also uses `setup_future_usage` to dynamically optimize your payment flow and comply with regional legislation and network rules, such as SCA.
         */
        setup_future_usage?: PaymentIntentData.SetupFutureUsage;
        /**
         * Text that appears on the customer's statement as the statement descriptor for a non-card charge. This value overrides the account's default statement descriptor. For information about requirements, including the 22-character limit, see [the Statement Descriptor docs](https://docs.stripe.com/get-started/account/statement-descriptors).
         *
         * Setting this value for a card charge returns an error. For card charges, set the [statement_descriptor_suffix](https://docs.stripe.com/get-started/account/statement-descriptors#dynamic) instead.
         */
        statement_descriptor?: string;
        /**
         * Provides information about a card charge. Concatenated to the account's [statement descriptor prefix](https://docs.stripe.com/get-started/account/statement-descriptors#static) to form the complete statement descriptor that appears on the customer's statement.
         */
        statement_descriptor_suffix?: string;
        /**
         * A string that identifies the resulting payment as part of a group. See the PaymentIntents [use case for connected accounts](https://docs.stripe.com/connect/separate-charges-and-transfers) for details.
         */
        transfer_group?: string;
    }
    type PaymentMethodCollection = 'always' | 'if_required' | OtherString;
    interface PaymentMethodOptions {
        /**
         * Configuration for `card` payment methods.
         */
        card?: PaymentMethodOptions.Card;
    }
    type PaymentMethodType = 'affirm' | 'afterpay_clearpay' | 'alipay' | 'alma' | 'au_becs_debit' | 'bacs_debit' | 'bancontact' | 'billie' | 'bizum' | 'blik' | 'boleto' | 'card' | 'cashapp' | 'eps' | 'fpx' | 'giropay' | 'grabpay' | 'ideal' | 'klarna' | 'konbini' | 'link' | 'mb_way' | 'mobilepay' | 'multibanco' | 'oxxo' | 'p24' | 'pay_by_bank' | 'paynow' | 'paypal' | 'payto' | 'pix' | 'promptpay' | 'satispay' | 'sepa_debit' | 'sofort' | 'sunbit' | 'swish' | 'twint' | 'upi' | 'us_bank_account' | 'wechat_pay' | 'zip' | OtherString;
    interface PhoneNumberCollection {
        /**
         * Set to `true` to enable phone number collection.
         */
        enabled: boolean;
    }
    interface Restrictions {
        /**
         * Configuration for the `completed_sessions` restriction type.
         */
        completed_sessions: Restrictions.CompletedSessions;
    }
    interface ShippingAddressCollection {
        /**
         * An array of two-letter ISO country codes representing which countries Checkout should provide as options for
         * shipping locations.
         */
        allowed_countries: Array<ShippingAddressCollection.AllowedCountry>;
    }
    interface ShippingOption {
        /**
         * The ID of the Shipping Rate to use for this shipping option.
         */
        shipping_rate?: string;
    }
    type SubmitType = 'auto' | 'book' | 'donate' | 'pay' | 'subscribe' | OtherString;
    interface SubscriptionData {
        /**
         * The subscription's description, meant to be displayable to the customer. Use this field to optionally store an explanation of the subscription for rendering in Stripe surfaces and certain local payment methods UIs.
         */
        description?: string;
        /**
         * All invoices will be billed using the specified settings.
         */
        invoice_settings?: SubscriptionData.InvoiceSettings;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that will declaratively set metadata on [Subscriptions](https://docs.stripe.com/api/subscriptions) generated from this payment link. Unlike object-level metadata, this field is declarative. Updates will clear prior values.
         */
        metadata?: MetadataParam;
        /**
         * Integer representing the number of trial period days before the customer is charged for the first time. Has to be at least 1.
         */
        trial_period_days?: number;
        /**
         * Settings related to subscription trials.
         */
        trial_settings?: SubscriptionData.TrialSettings;
    }
    interface TaxIdCollection {
        /**
         * Enable tax ID collection during checkout. Defaults to `false`.
         */
        enabled: boolean;
        /**
         * Describes whether a tax ID is required during checkout. Defaults to `never`. You can't set this parameter if `ui_mode` is `custom`.
         */
        required?: TaxIdCollection.Required;
    }
    interface TransferData {
        /**
         * The amount that will be transferred automatically when a charge succeeds.
         */
        amount?: number;
        /**
         * If specified, successful charges will be attributed to the destination
         * account for tax reporting, and the funds from charges will be transferred
         * to the destination account. The ID of the resulting transfer will be
         * returned on the successful charge's `transfer` field.
         */
        destination: string;
    }
    namespace AfterCompletion {
        interface HostedConfirmation {
            /**
             * A custom message to display to the customer after the purchase is complete.
             */
            custom_message?: string;
        }
        interface Redirect {
            /**
             * The URL the customer will be redirected to after the purchase is complete. You can embed `{CHECKOUT_SESSION_ID}` into the URL to have the `id` of the completed [checkout session](https://docs.stripe.com/api/checkout/sessions/object#checkout_session_object-id) included.
             */
            url: string;
        }
        type Type = 'hosted_confirmation' | 'redirect' | OtherString;
    }
    namespace AutomaticTax {
        interface Liability {
            /**
             * The connected account being referenced when `type` is `account`.
             */
            account?: string;
            /**
             * Type of the account referenced in the request.
             */
            type: Liability.Type;
        }
        namespace Liability {
            type Type = 'account' | 'self' | OtherString;
        }
    }
    namespace ConsentCollection {
        interface PaymentMethodReuseAgreement {
            /**
             * Determines the position and visibility of the payment method reuse agreement in the UI. When set to `auto`, Stripe's
             * defaults will be used. When set to `hidden`, the payment method reuse agreement text will always be hidden in the UI.
             */
            position: PaymentMethodReuseAgreement.Position;
        }
        type Promotions = 'auto' | 'none' | OtherString;
        type TermsOfService = 'none' | 'required' | OtherString;
        namespace PaymentMethodReuseAgreement {
            type Position = 'auto' | 'hidden' | OtherString;
        }
    }
    namespace CustomField {
        interface Dropdown {
            /**
             * The value that pre-fills the field on the payment page. Must match a `value` in the `options` array.
             */
            default_value?: string;
            /**
             * The options available for the customer to select. Up to 200 options allowed.
             */
            options: Array<Dropdown.Option>;
        }
        interface Label {
            /**
             * Custom text for the label, displayed to the customer. Up to 50 characters.
             */
            custom: string;
            /**
             * The type of the label.
             */
            type: 'custom';
        }
        interface Numeric {
            /**
             * The value that pre-fills the field on the payment page.
             */
            default_value?: string;
            /**
             * The maximum character length constraint for the customer's input.
             */
            maximum_length?: number;
            /**
             * The minimum character length requirement for the customer's input.
             */
            minimum_length?: number;
        }
        interface Text {
            /**
             * The value that pre-fills the field on the payment page.
             */
            default_value?: string;
            /**
             * The maximum character length constraint for the customer's input.
             */
            maximum_length?: number;
            /**
             * The minimum character length requirement for the customer's input.
             */
            minimum_length?: number;
        }
        type Type = 'dropdown' | 'numeric' | 'text' | OtherString;
        namespace Dropdown {
            interface Option {
                /**
                 * The label for the option, displayed to the customer. Up to 100 characters.
                 */
                label: string;
                /**
                 * The value for this option, not displayed to the customer, used by your integration to reconcile the option selected by the customer. Must be unique to this option, alphanumeric, and up to 100 characters.
                 */
                value: string;
            }
        }
    }
    namespace CustomText {
        interface AfterSubmit {
            /**
             * Text can be up to 1200 characters in length.
             */
            message: string;
        }
        interface ShippingAddress {
            /**
             * Text can be up to 1200 characters in length.
             */
            message: string;
        }
        interface Submit {
            /**
             * Text can be up to 1200 characters in length.
             */
            message: string;
        }
        interface TermsOfServiceAcceptance {
            /**
             * Text can be up to 1200 characters in length.
             */
            message: string;
        }
    }
    namespace InvoiceCreation {
        interface InvoiceData {
            /**
             * The account tax IDs associated with the invoice.
             */
            account_tax_ids?: Emptyable<Array<string>>;
            /**
             * Default custom fields to be displayed on invoices for this customer.
             */
            custom_fields?: Emptyable<Array<InvoiceData.CustomField>>;
            /**
             * An arbitrary string attached to the object. Often useful for displaying to users.
             */
            description?: string;
            /**
             * Default footer to be displayed on invoices for this customer.
             */
            footer?: string;
            /**
             * The connected account that issues the invoice. The invoice is presented with the branding and support information of the specified account.
             */
            issuer?: InvoiceData.Issuer;
            /**
             * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
             */
            metadata?: Emptyable<MetadataParam>;
            /**
             * Default options for invoice PDF rendering for this customer.
             */
            rendering_options?: Emptyable<InvoiceData.RenderingOptions>;
        }
        namespace InvoiceData {
            interface CustomField {
                /**
                 * The name of the custom field. This may be up to 40 characters.
                 */
                name: string;
                /**
                 * The value of the custom field. This may be up to 140 characters.
                 */
                value: string;
            }
            interface Issuer {
                /**
                 * The connected account being referenced when `type` is `account`.
                 */
                account?: string;
                /**
                 * Type of the account referenced in the request.
                 */
                type: Issuer.Type;
            }
            interface RenderingOptions {
                /**
                 * How line-item prices and amounts will be displayed with respect to tax on invoice PDFs. One of `exclude_tax` or `include_inclusive_tax`. `include_inclusive_tax` will include inclusive tax (and exclude exclusive tax) in invoice PDF amounts. `exclude_tax` will exclude all tax (inclusive and exclusive alike) from invoice PDF amounts.
                 */
                amount_tax_display?: Emptyable<RenderingOptions.AmountTaxDisplay>;
                /**
                 * ID of the invoice rendering template to use for this invoice.
                 */
                template?: string;
            }
            namespace Issuer {
                type Type = 'account' | 'self' | OtherString;
            }
            namespace RenderingOptions {
                type AmountTaxDisplay = 'exclude_tax' | 'include_inclusive_tax' | OtherString;
            }
        }
    }
    namespace LineItem {
        interface AdjustableQuantity {
            /**
             * Set to true if the quantity can be adjusted to any non-negative Integer.
             */
            enabled: boolean;
            /**
             * The maximum quantity the customer can purchase. By default this value is 99. You can specify a value up to 999999.
             */
            maximum?: number;
            /**
             * The minimum quantity the customer can purchase. By default this value is 0. If there is only one item in the cart then that item's quantity cannot go down to 0.
             */
            minimum?: number;
        }
        interface PriceData {
            /**
             * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
             */
            currency: string;
            /**
             * The ID of the [Product](https://docs.stripe.com/api/products) that this [Price](https://docs.stripe.com/api/prices) will belong to. One of `product` or `product_data` is required.
             */
            product?: string;
            /**
             * Data used to generate a new [Product](https://docs.stripe.com/api/products) object inline. One of `product` or `product_data` is required.
             */
            product_data?: PriceData.ProductData;
            /**
             * The recurring components of a price such as `interval` and `interval_count`.
             */
            recurring?: PriceData.Recurring;
            /**
             * Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
             */
            tax_behavior?: PriceData.TaxBehavior;
            /**
             * A non-negative integer in cents (or local equivalent) representing how much to charge. One of `unit_amount` or `unit_amount_decimal` is required.
             */
            unit_amount?: number;
            /**
             * Same as `unit_amount`, but accepts a decimal value in cents (or local equivalent) with at most 12 decimal places. Only one of `unit_amount` and `unit_amount_decimal` can be set.
             */
            unit_amount_decimal?: Decimal;
        }
        namespace PriceData {
            interface ProductData {
                /**
                 * The product's description, meant to be displayable to the customer. Use this field to optionally store a long form explanation of the product being sold for your own rendering purposes.
                 */
                description?: string;
                /**
                 * A list of up to 8 URLs of images for this product, meant to be displayable to the customer.
                 */
                images?: Array<string>;
                /**
                 * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
                 */
                metadata?: MetadataParam;
                /**
                 * The product's name, meant to be displayable to the customer.
                 */
                name: string;
                /**
                 * A [tax code](https://docs.stripe.com/tax/tax-categories) ID.
                 */
                tax_code?: string;
                /**
                 * A label that represents units of this product. When set, this will be included in customers' receipts, invoices, Checkout, and the customer portal.
                 */
                unit_label?: string;
            }
            interface Recurring {
                /**
                 * Specifies billing frequency. Either `day`, `week`, `month` or `year`.
                 */
                interval: Recurring.Interval;
                /**
                 * The number of intervals between subscription billings. For example, `interval=month` and `interval_count=3` bills every 3 months. Maximum of three years interval allowed (3 years, 36 months, or 156 weeks).
                 */
                interval_count?: number;
            }
            type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
            namespace Recurring {
                type Interval = 'day' | 'month' | 'week' | 'year' | OtherString;
            }
        }
    }
    namespace NameCollection {
        interface Business {
            /**
             * Enable business name collection on the payment link. Defaults to `false`.
             */
            enabled: boolean;
            /**
             * Whether the customer is required to provide their business name before checking out. Defaults to `false`.
             */
            optional?: boolean;
        }
        interface Individual {
            /**
             * Enable individual name collection on the payment link. Defaults to `false`.
             */
            enabled: boolean;
            /**
             * Whether the customer is required to provide their full name before checking out. Defaults to `false`.
             */
            optional?: boolean;
        }
    }
    namespace OptionalItem {
        interface AdjustableQuantity {
            /**
             * Set to true if the quantity can be adjusted to any non-negative integer.
             */
            enabled: boolean;
            /**
             * The maximum quantity of this item the customer can purchase. By default this value is 99.
             */
            maximum?: number;
            /**
             * The minimum quantity of this item the customer must purchase, if they choose to purchase it. Because this item is optional, the customer will always be able to remove it from their order, even if the `minimum` configured here is greater than 0. By default this value is 0.
             */
            minimum?: number;
        }
    }
    namespace PaymentIntentData {
        type CaptureMethod = 'automatic' | 'automatic_async' | 'manual' | OtherString;
        type SetupFutureUsage = 'off_session' | 'on_session' | OtherString;
    }
    namespace PaymentMethodOptions {
        interface Card {
            /**
             * Restrictions to apply to the card payment method. For example, you can block specific card brands.
             */
            restrictions?: Card.Restrictions;
        }
        namespace Card {
            interface Restrictions {
                /**
                 * The card brands to block. If a customer enters or selects a card belonging to a blocked brand, they can't complete the payment.
                 */
                brands_blocked?: Array<Restrictions.BrandsBlocked>;
            }
            namespace Restrictions {
                type BrandsBlocked = 'american_express' | 'discover_global_network' | 'mastercard' | 'visa' | OtherString;
            }
        }
    }
    namespace Restrictions {
        interface CompletedSessions {
            /**
             * The maximum number of checkout sessions that can be completed for the `completed_sessions` restriction to be met.
             */
            limit: number;
        }
    }
    namespace ShippingAddressCollection {
        type AllowedCountry = 'AC' | 'AD' | 'AE' | 'AF' | 'AG' | 'AI' | 'AL' | 'AM' | 'AO' | 'AQ' | 'AR' | 'AT' | 'AU' | 'AW' | 'AX' | 'AZ' | 'BA' | 'BB' | 'BD' | 'BE' | 'BF' | 'BG' | 'BH' | 'BI' | 'BJ' | 'BL' | 'BM' | 'BN' | 'BO' | 'BQ' | 'BR' | 'BS' | 'BT' | 'BV' | 'BW' | 'BY' | 'BZ' | 'CA' | 'CD' | 'CF' | 'CG' | 'CH' | 'CI' | 'CK' | 'CL' | 'CM' | 'CN' | 'CO' | 'CR' | 'CV' | 'CW' | 'CY' | 'CZ' | 'DE' | 'DJ' | 'DK' | 'DM' | 'DO' | 'DZ' | 'EC' | 'EE' | 'EG' | 'EH' | 'ER' | 'ES' | 'ET' | 'FI' | 'FJ' | 'FK' | 'FO' | 'FR' | 'GA' | 'GB' | 'GD' | 'GE' | 'GF' | 'GG' | 'GH' | 'GI' | 'GL' | 'GM' | 'GN' | 'GP' | 'GQ' | 'GR' | 'GS' | 'GT' | 'GU' | 'GW' | 'GY' | 'HK' | 'HN' | 'HR' | 'HT' | 'HU' | 'ID' | 'IE' | 'IL' | 'IM' | 'IN' | 'IO' | 'IQ' | 'IS' | 'IT' | 'JE' | 'JM' | 'JO' | 'JP' | 'KE' | 'KG' | 'KH' | 'KI' | 'KM' | 'KN' | 'KR' | 'KW' | 'KY' | 'KZ' | 'LA' | 'LB' | 'LC' | 'LI' | 'LK' | 'LR' | 'LS' | 'LT' | 'LU' | 'LV' | 'LY' | 'MA' | 'MC' | 'MD' | 'ME' | 'MF' | 'MG' | 'MK' | 'ML' | 'MM' | 'MN' | 'MO' | 'MQ' | 'MR' | 'MS' | 'MT' | 'MU' | 'MV' | 'MW' | 'MX' | 'MY' | 'MZ' | 'NA' | 'NC' | 'NE' | 'NG' | 'NI' | 'NL' | 'NO' | 'NP' | 'NR' | 'NU' | 'NZ' | 'OM' | 'PA' | 'PE' | 'PF' | 'PG' | 'PH' | 'PK' | 'PL' | 'PM' | 'PN' | 'PR' | 'PS' | 'PT' | 'PY' | 'QA' | 'RE' | 'RO' | 'RS' | 'RU' | 'RW' | 'SA' | 'SB' | 'SC' | 'SD' | 'SE' | 'SG' | 'SH' | 'SI' | 'SJ' | 'SK' | 'SL' | 'SM' | 'SN' | 'SO' | 'SR' | 'SS' | 'ST' | 'SV' | 'SX' | 'SZ' | 'TA' | 'TC' | 'TD' | 'TF' | 'TG' | 'TH' | 'TJ' | 'TK' | 'TL' | 'TM' | 'TN' | 'TO' | 'TR' | 'TT' | 'TV' | 'TW' | 'TZ' | 'UA' | 'UG' | 'US' | 'UY' | 'UZ' | 'VA' | 'VC' | 'VE' | 'VG' | 'VN' | 'VU' | 'WF' | 'WS' | 'XK' | 'YE' | 'YT' | 'ZA' | 'ZM' | 'ZW' | 'ZZ' | OtherString;
    }
    namespace SubscriptionData {
        interface InvoiceSettings {
            /**
             * The connected account that issues the invoice. The invoice is presented with the branding and support information of the specified account.
             */
            issuer?: InvoiceSettings.Issuer;
        }
        interface TrialSettings {
            /**
             * Defines how the subscription should behave when the user's free trial ends.
             */
            end_behavior: TrialSettings.EndBehavior;
        }
        namespace InvoiceSettings {
            interface Issuer {
                /**
                 * The connected account being referenced when `type` is `account`.
                 */
                account?: string;
                /**
                 * Type of the account referenced in the request.
                 */
                type: Issuer.Type;
            }
            namespace Issuer {
                type Type = 'account' | 'self' | OtherString;
            }
        }
        namespace TrialSettings {
            interface EndBehavior {
                /**
                 * Indicates how the subscription should change when the trial ends if the user did not provide a payment method.
                 */
                missing_payment_method: EndBehavior.MissingPaymentMethod;
            }
            namespace EndBehavior {
                type MissingPaymentMethod = 'cancel' | 'create_invoice' | 'pause' | OtherString;
            }
        }
    }
    namespace TaxIdCollection {
        type Required = 'if_supported' | 'never' | OtherString;
    }
}
export interface PaymentLinkRetrieveParams {
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
}
export interface PaymentLinkUpdateParams {
    /**
     * Whether the payment link's `url` is active. If `false`, customers visiting the URL will be shown a page saying that the link has been deactivated.
     */
    active?: boolean;
    /**
     * Behavior after the purchase is complete.
     */
    after_completion?: PaymentLinkUpdateParams.AfterCompletion;
    /**
     * Enables user redeemable promotion codes.
     */
    allow_promotion_codes?: boolean;
    /**
     * The amount of the application fee (if any) that will be requested to be applied to the payment and transferred to the application owner's Stripe account. Can only be applied when there are no line items with recurring prices.
     */
    application_fee_amount?: Emptyable<number>;
    /**
     * A non-negative decimal between 0 and 100, with at most two decimal places. This represents the percentage of the subscription invoice total that will be transferred to the application owner's Stripe account. There must be at least 1 line item with a recurring price to use this field.
     */
    application_fee_percent?: Emptyable<number>;
    /**
     * Configuration for automatic tax collection.
     */
    automatic_tax?: PaymentLinkUpdateParams.AutomaticTax;
    /**
     * Configuration for collecting the customer's billing address. Defaults to `auto`.
     */
    billing_address_collection?: PaymentLinkUpdateParams.BillingAddressCollection;
    /**
     * Configure fields to gather active consent from customers.
     */
    consent_collection?: PaymentLinkUpdateParams.ConsentCollection;
    /**
     * Collect additional information from your customer using custom fields. Up to 3 fields are supported. You can't set this parameter if `ui_mode` is `custom`.
     */
    custom_fields?: Emptyable<Array<PaymentLinkUpdateParams.CustomField>>;
    /**
     * Display additional text for your customers using custom text. You can't set this parameter if `ui_mode` is `custom`.
     */
    custom_text?: PaymentLinkUpdateParams.CustomText;
    /**
     * Configures whether [checkout sessions](https://docs.stripe.com/api/checkout/sessions) created by this payment link create a [Customer](https://docs.stripe.com/api/customers).
     */
    customer_creation?: PaymentLinkUpdateParams.CustomerCreation;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * The custom message to be displayed to a customer when a payment link is no longer active.
     */
    inactive_message?: Emptyable<string>;
    /**
     * Generate a post-purchase Invoice for one-time payments.
     */
    invoice_creation?: PaymentLinkUpdateParams.InvoiceCreation;
    /**
     * The line items representing what is being sold. Each line item represents an item being sold. Up to 20 line items are supported.
     */
    line_items?: Array<PaymentLinkUpdateParams.LineItem>;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`. Metadata associated with this Payment Link will automatically be copied to [checkout sessions](https://docs.stripe.com/api/checkout/sessions) created by this payment link.
     */
    metadata?: MetadataParam;
    /**
     * Controls settings applied for collecting the customer's name.
     */
    name_collection?: Emptyable<PaymentLinkUpdateParams.NameCollection>;
    /**
     * The account on behalf of which to charge.
     */
    on_behalf_of?: Emptyable<string>;
    /**
     * A list of optional items the customer can add to their order at checkout. Use this parameter to pass one-time or recurring [Prices](https://docs.stripe.com/api/prices).
     * There is a maximum of 10 optional items allowed on a payment link, and the existing limits on the number of line items allowed on a payment link apply to the combined number of line items and optional items.
     * There is a maximum of 20 combined line items and optional items.
     */
    optional_items?: Emptyable<Array<PaymentLinkUpdateParams.OptionalItem>>;
    /**
     * A subset of parameters to be passed to PaymentIntent creation for Checkout Sessions in `payment` mode.
     */
    payment_intent_data?: PaymentLinkUpdateParams.PaymentIntentData;
    /**
     * Specify whether Checkout should collect a payment method. When set to `if_required`, Checkout will not collect a payment method when the total due for the session is 0.This may occur if the Checkout Session includes a free trial or a discount.
     *
     * Can only be set in `subscription` mode. Defaults to `always`.
     *
     * If you'd like information on how to collect a payment method outside of Checkout, read the guide on [configuring subscriptions with a free trial](https://docs.stripe.com/payments/checkout/free-trials).
     */
    payment_method_collection?: PaymentLinkUpdateParams.PaymentMethodCollection;
    /**
     * Payment-method-specific configuration.
     */
    payment_method_options?: Emptyable<PaymentLinkUpdateParams.PaymentMethodOptions>;
    /**
     * The list of payment method types that customers can use. Pass an empty string to enable dynamic payment methods that use your [payment method settings](https://dashboard.stripe.com/settings/payment_methods).
     */
    payment_method_types?: Emptyable<Array<PaymentLinkUpdateParams.PaymentMethodType>>;
    /**
     * Controls phone number collection settings during checkout.
     *
     * We recommend that you review your privacy policy and check with your legal contacts.
     */
    phone_number_collection?: PaymentLinkUpdateParams.PhoneNumberCollection;
    /**
     * Settings that restrict the usage of a payment link.
     */
    restrictions?: Emptyable<PaymentLinkUpdateParams.Restrictions>;
    /**
     * Configuration for collecting the customer's shipping address.
     */
    shipping_address_collection?: Emptyable<PaymentLinkUpdateParams.ShippingAddressCollection>;
    /**
     * The shipping rate options to apply to [checkout sessions](https://docs.stripe.com/api/checkout/sessions) created by this payment link.
     */
    shipping_options?: Emptyable<Array<PaymentLinkUpdateParams.ShippingOption>>;
    /**
     * Describes the type of transaction being performed in order to customize relevant text on the page, such as the submit button. Changing this value will also affect the hostname in the [url](https://docs.stripe.com/api/payment_links/payment_links/object#url) property (example: `donate.stripe.com`).
     */
    submit_type?: PaymentLinkUpdateParams.SubmitType;
    /**
     * When creating a subscription, the specified configuration data will be used. There must be at least one line item with a recurring price to use `subscription_data`.
     */
    subscription_data?: PaymentLinkUpdateParams.SubscriptionData;
    /**
     * Controls tax ID collection during checkout.
     */
    tax_id_collection?: PaymentLinkUpdateParams.TaxIdCollection;
    /**
     * The account (if any) the payments will be attributed to for tax reporting, and where funds from each payment will be transferred to.
     */
    transfer_data?: Emptyable<PaymentLinkUpdateParams.TransferData>;
}
export declare namespace PaymentLinkUpdateParams {
    interface AfterCompletion {
        /**
         * Configuration when `type=hosted_confirmation`.
         */
        hosted_confirmation?: AfterCompletion.HostedConfirmation;
        /**
         * Configuration when `type=redirect`.
         */
        redirect?: AfterCompletion.Redirect;
        /**
         * The specified behavior after the purchase is complete. Either `redirect` or `hosted_confirmation`.
         */
        type: AfterCompletion.Type;
    }
    interface AutomaticTax {
        /**
         * Set to `true` to [calculate tax automatically](https://docs.stripe.com/tax) using the customer's location.
         *
         * Enabling this parameter causes the payment link to collect any billing address information necessary for tax calculation.
         */
        enabled: boolean;
        /**
         * The account that's liable for tax. If set, the business address and tax registrations required to perform the tax calculation are loaded from this account. The tax transaction is returned in the report of the connected account.
         */
        liability?: AutomaticTax.Liability;
    }
    type BillingAddressCollection = 'auto' | 'required' | OtherString;
    interface ConsentCollection {
        /**
         * Determines the display of payment method reuse agreement text in the UI. If set to `hidden`, it will hide legal text related to the reuse of a payment method.
         */
        payment_method_reuse_agreement?: ConsentCollection.PaymentMethodReuseAgreement;
        /**
         * If set to `auto`, enables the collection of customer consent for promotional communications. The Checkout
         * Session will determine whether to display an option to opt into promotional communication
         * from the merchant depending on the customer's locale. Only available to US merchants and US customers.
         */
        promotions?: ConsentCollection.Promotions;
        /**
         * If set to `required`, it requires customers to check a terms of service checkbox before being able to pay.
         * There must be a valid terms of service URL set in your [Dashboard settings](https://dashboard.stripe.com/settings/public).
         */
        terms_of_service?: ConsentCollection.TermsOfService;
    }
    interface CustomField {
        /**
         * Configuration for `type=dropdown` fields.
         */
        dropdown?: CustomField.Dropdown;
        /**
         * String of your choice that your integration can use to reconcile this field. Must be unique to this field, alphanumeric, and up to 200 characters.
         */
        key: string;
        /**
         * The label for the field, displayed to the customer.
         */
        label: CustomField.Label;
        /**
         * Configuration for `type=numeric` fields.
         */
        numeric?: CustomField.Numeric;
        /**
         * Whether the customer is required to complete the field before completing the Checkout Session. Defaults to `false`.
         */
        optional?: boolean;
        /**
         * Configuration for `type=text` fields.
         */
        text?: CustomField.Text;
        /**
         * The type of the field.
         */
        type: CustomField.Type;
    }
    interface CustomText {
        /**
         * Custom text that should be displayed after the payment confirmation button.
         */
        after_submit?: Emptyable<CustomText.AfterSubmit>;
        /**
         * Custom text that should be displayed alongside shipping address collection.
         */
        shipping_address?: Emptyable<CustomText.ShippingAddress>;
        /**
         * Custom text that should be displayed alongside the payment confirmation button.
         */
        submit?: Emptyable<CustomText.Submit>;
        /**
         * Custom text that should be displayed in place of the default terms of service agreement text.
         */
        terms_of_service_acceptance?: Emptyable<CustomText.TermsOfServiceAcceptance>;
    }
    type CustomerCreation = 'always' | 'if_required' | OtherString;
    interface InvoiceCreation {
        /**
         * Whether the feature is enabled
         */
        enabled: boolean;
        /**
         * Invoice PDF configuration.
         */
        invoice_data?: InvoiceCreation.InvoiceData;
    }
    interface LineItem {
        /**
         * When set, provides configuration for this item's quantity to be adjusted by the customer during checkout.
         */
        adjustable_quantity?: LineItem.AdjustableQuantity;
        /**
         * The ID of an existing line item on the payment link.
         */
        id: string;
        /**
         * The quantity of the line item being purchased.
         */
        quantity?: number;
    }
    interface NameCollection {
        /**
         * Controls settings applied for collecting the customer's business name.
         */
        business?: NameCollection.Business;
        /**
         * Controls settings applied for collecting the customer's individual name.
         */
        individual?: NameCollection.Individual;
    }
    interface OptionalItem {
        /**
         * When set, provides configuration for the customer to adjust the quantity of the line item created when a customer chooses to add this optional item to their order.
         */
        adjustable_quantity?: OptionalItem.AdjustableQuantity;
        /**
         * The ID of the [Price](https://docs.stripe.com/api/prices) or [Plan](https://docs.stripe.com/api/plans) object.
         */
        price: string;
        /**
         * The initial quantity of the line item created when a customer chooses to add this optional item to their order.
         */
        quantity: number;
    }
    interface PaymentIntentData {
        /**
         * An arbitrary string attached to the object. Often useful for displaying to users.
         */
        description?: Emptyable<string>;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that will declaratively set metadata on [Payment Intents](https://docs.stripe.com/api/payment_intents) generated from this payment link. Unlike object-level metadata, this field is declarative. Updates will clear prior values.
         */
        metadata?: Emptyable<MetadataParam>;
        /**
         * Indicates that you intend to [make future payments](https://docs.stripe.com/payments/payment-intents#future-usage) with the payment method collected by this Checkout Session.
         *
         * When setting this to `on_session`, Checkout will show a notice to the customer that their payment details will be saved.
         *
         * When setting this to `off_session`, Checkout will show a notice to the customer that their payment details will be saved and used for future payments.
         *
         * If a Customer has been provided or Checkout creates a new Customer,Checkout will attach the payment method to the Customer.
         *
         * If Checkout does not create a Customer, the payment method is not attached to a Customer. To reuse the payment method, you can retrieve it from the Checkout Session's PaymentIntent.
         *
         * When processing card payments, Checkout also uses `setup_future_usage` to dynamically optimize your payment flow and comply with regional legislation and network rules, such as SCA.
         */
        setup_future_usage?: Emptyable<PaymentIntentData.SetupFutureUsage>;
        /**
         * Text that appears on the customer's statement as the statement descriptor for a non-card charge. This value overrides the account's default statement descriptor. For information about requirements, including the 22-character limit, see [the Statement Descriptor docs](https://docs.stripe.com/get-started/account/statement-descriptors).
         *
         * Setting this value for a card charge returns an error. For card charges, set the [statement_descriptor_suffix](https://docs.stripe.com/get-started/account/statement-descriptors#dynamic) instead.
         */
        statement_descriptor?: Emptyable<string>;
        /**
         * Provides information about a card charge. Concatenated to the account's [statement descriptor prefix](https://docs.stripe.com/get-started/account/statement-descriptors#static) to form the complete statement descriptor that appears on the customer's statement.
         */
        statement_descriptor_suffix?: Emptyable<string>;
        /**
         * A string that identifies the resulting payment as part of a group. See the PaymentIntents [use case for connected accounts](https://docs.stripe.com/connect/separate-charges-and-transfers) for details.
         */
        transfer_group?: Emptyable<string>;
    }
    type PaymentMethodCollection = 'always' | 'if_required' | OtherString;
    interface PaymentMethodOptions {
        /**
         * Configuration for `card` payment methods.
         */
        card?: Emptyable<PaymentMethodOptions.Card>;
    }
    type PaymentMethodType = 'affirm' | 'afterpay_clearpay' | 'alipay' | 'alma' | 'au_becs_debit' | 'bacs_debit' | 'bancontact' | 'billie' | 'bizum' | 'blik' | 'boleto' | 'card' | 'cashapp' | 'eps' | 'fpx' | 'giropay' | 'grabpay' | 'ideal' | 'klarna' | 'konbini' | 'link' | 'mb_way' | 'mobilepay' | 'multibanco' | 'oxxo' | 'p24' | 'pay_by_bank' | 'paynow' | 'paypal' | 'payto' | 'pix' | 'promptpay' | 'satispay' | 'sepa_debit' | 'sofort' | 'sunbit' | 'swish' | 'twint' | 'upi' | 'us_bank_account' | 'wechat_pay' | 'zip' | OtherString;
    interface PhoneNumberCollection {
        /**
         * Set to `true` to enable phone number collection.
         */
        enabled: boolean;
    }
    interface Restrictions {
        /**
         * Configuration for the `completed_sessions` restriction type.
         */
        completed_sessions: Restrictions.CompletedSessions;
    }
    interface ShippingAddressCollection {
        /**
         * An array of two-letter ISO country codes representing which countries Checkout should provide as options for
         * shipping locations.
         */
        allowed_countries: Array<ShippingAddressCollection.AllowedCountry>;
    }
    interface ShippingOption {
        /**
         * The ID of the Shipping Rate to use for this shipping option.
         */
        shipping_rate?: string;
    }
    type SubmitType = 'auto' | 'book' | 'donate' | 'pay' | 'subscribe' | OtherString;
    interface SubscriptionData {
        /**
         * All invoices will be billed using the specified settings.
         */
        invoice_settings?: SubscriptionData.InvoiceSettings;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that will declaratively set metadata on [Subscriptions](https://docs.stripe.com/api/subscriptions) generated from this payment link. Unlike object-level metadata, this field is declarative. Updates will clear prior values.
         */
        metadata?: Emptyable<MetadataParam>;
        /**
         * Integer representing the number of trial period days before the customer is charged for the first time. Has to be at least 1.
         */
        trial_period_days?: Emptyable<number>;
        /**
         * Settings related to subscription trials.
         */
        trial_settings?: Emptyable<SubscriptionData.TrialSettings>;
    }
    interface TaxIdCollection {
        /**
         * Enable tax ID collection during checkout. Defaults to `false`.
         */
        enabled: boolean;
        /**
         * Describes whether a tax ID is required during checkout. Defaults to `never`. You can't set this parameter if `ui_mode` is `custom`.
         */
        required?: TaxIdCollection.Required;
    }
    interface TransferData {
        /**
         * The amount that will be transferred automatically when a charge succeeds.
         */
        amount?: Emptyable<number>;
        /**
         * If specified, successful charges will be attributed to the destination
         *  account for tax reporting, and the funds from charges will be transferred
         *  to the destination account. The ID of the resulting transfer will be
         *  returned on the successful charge's `transfer` field.
         */
        destination: string;
    }
    namespace AfterCompletion {
        interface HostedConfirmation {
            /**
             * A custom message to display to the customer after the purchase is complete.
             */
            custom_message?: string;
        }
        interface Redirect {
            /**
             * The URL the customer will be redirected to after the purchase is complete. You can embed `{CHECKOUT_SESSION_ID}` into the URL to have the `id` of the completed [checkout session](https://docs.stripe.com/api/checkout/sessions/object#checkout_session_object-id) included.
             */
            url: string;
        }
        type Type = 'hosted_confirmation' | 'redirect' | OtherString;
    }
    namespace AutomaticTax {
        interface Liability {
            /**
             * The connected account being referenced when `type` is `account`.
             */
            account?: string;
            /**
             * Type of the account referenced in the request.
             */
            type: Liability.Type;
        }
        namespace Liability {
            type Type = 'account' | 'self' | OtherString;
        }
    }
    namespace ConsentCollection {
        interface PaymentMethodReuseAgreement {
            /**
             * Determines the position and visibility of the payment method reuse agreement in the UI. When set to `auto`, Stripe's
             * defaults will be used. When set to `hidden`, the payment method reuse agreement text will always be hidden in the UI.
             */
            position: PaymentMethodReuseAgreement.Position;
        }
        type Promotions = 'auto' | 'none' | OtherString;
        type TermsOfService = 'none' | 'required' | OtherString;
        namespace PaymentMethodReuseAgreement {
            type Position = 'auto' | 'hidden' | OtherString;
        }
    }
    namespace CustomField {
        interface Dropdown {
            /**
             * The value that pre-fills the field on the payment page. Must match a `value` in the `options` array.
             */
            default_value?: string;
            /**
             * The options available for the customer to select. Up to 200 options allowed.
             */
            options: Array<Dropdown.Option>;
        }
        interface Label {
            /**
             * Custom text for the label, displayed to the customer. Up to 50 characters.
             */
            custom: string;
            /**
             * The type of the label.
             */
            type: 'custom';
        }
        interface Numeric {
            /**
             * The value that pre-fills the field on the payment page.
             */
            default_value?: string;
            /**
             * The maximum character length constraint for the customer's input.
             */
            maximum_length?: number;
            /**
             * The minimum character length requirement for the customer's input.
             */
            minimum_length?: number;
        }
        interface Text {
            /**
             * The value that pre-fills the field on the payment page.
             */
            default_value?: string;
            /**
             * The maximum character length constraint for the customer's input.
             */
            maximum_length?: number;
            /**
             * The minimum character length requirement for the customer's input.
             */
            minimum_length?: number;
        }
        type Type = 'dropdown' | 'numeric' | 'text' | OtherString;
        namespace Dropdown {
            interface Option {
                /**
                 * The label for the option, displayed to the customer. Up to 100 characters.
                 */
                label: string;
                /**
                 * The value for this option, not displayed to the customer, used by your integration to reconcile the option selected by the customer. Must be unique to this option, alphanumeric, and up to 100 characters.
                 */
                value: string;
            }
        }
    }
    namespace CustomText {
        interface AfterSubmit {
            /**
             * Text can be up to 1200 characters in length.
             */
            message: string;
        }
        interface ShippingAddress {
            /**
             * Text can be up to 1200 characters in length.
             */
            message: string;
        }
        interface Submit {
            /**
             * Text can be up to 1200 characters in length.
             */
            message: string;
        }
        interface TermsOfServiceAcceptance {
            /**
             * Text can be up to 1200 characters in length.
             */
            message: string;
        }
    }
    namespace InvoiceCreation {
        interface InvoiceData {
            /**
             * The account tax IDs associated with the invoice.
             */
            account_tax_ids?: Emptyable<Array<string>>;
            /**
             * Default custom fields to be displayed on invoices for this customer.
             */
            custom_fields?: Emptyable<Array<InvoiceData.CustomField>>;
            /**
             * An arbitrary string attached to the object. Often useful for displaying to users.
             */
            description?: string;
            /**
             * Default footer to be displayed on invoices for this customer.
             */
            footer?: string;
            /**
             * The connected account that issues the invoice. The invoice is presented with the branding and support information of the specified account.
             */
            issuer?: InvoiceData.Issuer;
            /**
             * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
             */
            metadata?: Emptyable<MetadataParam>;
            /**
             * Default options for invoice PDF rendering for this customer.
             */
            rendering_options?: Emptyable<InvoiceData.RenderingOptions>;
        }
        namespace InvoiceData {
            interface CustomField {
                /**
                 * The name of the custom field. This may be up to 40 characters.
                 */
                name: string;
                /**
                 * The value of the custom field. This may be up to 140 characters.
                 */
                value: string;
            }
            interface Issuer {
                /**
                 * The connected account being referenced when `type` is `account`.
                 */
                account?: string;
                /**
                 * Type of the account referenced in the request.
                 */
                type: Issuer.Type;
            }
            interface RenderingOptions {
                /**
                 * How line-item prices and amounts will be displayed with respect to tax on invoice PDFs. One of `exclude_tax` or `include_inclusive_tax`. `include_inclusive_tax` will include inclusive tax (and exclude exclusive tax) in invoice PDF amounts. `exclude_tax` will exclude all tax (inclusive and exclusive alike) from invoice PDF amounts.
                 */
                amount_tax_display?: Emptyable<RenderingOptions.AmountTaxDisplay>;
                /**
                 * ID of the invoice rendering template to use for this invoice.
                 */
                template?: string;
            }
            namespace Issuer {
                type Type = 'account' | 'self' | OtherString;
            }
            namespace RenderingOptions {
                type AmountTaxDisplay = 'exclude_tax' | 'include_inclusive_tax' | OtherString;
            }
        }
    }
    namespace LineItem {
        interface AdjustableQuantity {
            /**
             * Set to true if the quantity can be adjusted to any non-negative Integer.
             */
            enabled: boolean;
            /**
             * The maximum quantity the customer can purchase. By default this value is 99. You can specify a value up to 999999.
             */
            maximum?: number;
            /**
             * The minimum quantity the customer can purchase. By default this value is 0. If there is only one item in the cart then that item's quantity cannot go down to 0.
             */
            minimum?: number;
        }
    }
    namespace NameCollection {
        interface Business {
            /**
             * Enable business name collection on the payment link. Defaults to `false`.
             */
            enabled: boolean;
            /**
             * Whether the customer is required to provide their business name before checking out. Defaults to `false`.
             */
            optional?: boolean;
        }
        interface Individual {
            /**
             * Enable individual name collection on the payment link. Defaults to `false`.
             */
            enabled: boolean;
            /**
             * Whether the customer is required to provide their full name before checking out. Defaults to `false`.
             */
            optional?: boolean;
        }
    }
    namespace OptionalItem {
        interface AdjustableQuantity {
            /**
             * Set to true if the quantity can be adjusted to any non-negative integer.
             */
            enabled: boolean;
            /**
             * The maximum quantity of this item the customer can purchase. By default this value is 99.
             */
            maximum?: number;
            /**
             * The minimum quantity of this item the customer must purchase, if they choose to purchase it. Because this item is optional, the customer will always be able to remove it from their order, even if the `minimum` configured here is greater than 0. By default this value is 0.
             */
            minimum?: number;
        }
    }
    namespace PaymentIntentData {
        type SetupFutureUsage = 'off_session' | 'on_session' | OtherString;
    }
    namespace PaymentMethodOptions {
        interface Card {
            /**
             * Restrictions to apply to the card payment method. For example, you can block specific card brands.
             */
            restrictions?: Emptyable<Card.Restrictions>;
        }
        namespace Card {
            interface Restrictions {
                /**
                 * The card brands to block. If a customer enters or selects a card belonging to a blocked brand, they can't complete the payment.
                 */
                brands_blocked?: Emptyable<Array<Restrictions.BrandsBlocked>>;
            }
            namespace Restrictions {
                type BrandsBlocked = 'american_express' | 'discover_global_network' | 'mastercard' | 'visa' | OtherString;
            }
        }
    }
    namespace Restrictions {
        interface CompletedSessions {
            /**
             * The maximum number of checkout sessions that can be completed for the `completed_sessions` restriction to be met.
             */
            limit: number;
        }
    }
    namespace ShippingAddressCollection {
        type AllowedCountry = 'AC' | 'AD' | 'AE' | 'AF' | 'AG' | 'AI' | 'AL' | 'AM' | 'AO' | 'AQ' | 'AR' | 'AT' | 'AU' | 'AW' | 'AX' | 'AZ' | 'BA' | 'BB' | 'BD' | 'BE' | 'BF' | 'BG' | 'BH' | 'BI' | 'BJ' | 'BL' | 'BM' | 'BN' | 'BO' | 'BQ' | 'BR' | 'BS' | 'BT' | 'BV' | 'BW' | 'BY' | 'BZ' | 'CA' | 'CD' | 'CF' | 'CG' | 'CH' | 'CI' | 'CK' | 'CL' | 'CM' | 'CN' | 'CO' | 'CR' | 'CV' | 'CW' | 'CY' | 'CZ' | 'DE' | 'DJ' | 'DK' | 'DM' | 'DO' | 'DZ' | 'EC' | 'EE' | 'EG' | 'EH' | 'ER' | 'ES' | 'ET' | 'FI' | 'FJ' | 'FK' | 'FO' | 'FR' | 'GA' | 'GB' | 'GD' | 'GE' | 'GF' | 'GG' | 'GH' | 'GI' | 'GL' | 'GM' | 'GN' | 'GP' | 'GQ' | 'GR' | 'GS' | 'GT' | 'GU' | 'GW' | 'GY' | 'HK' | 'HN' | 'HR' | 'HT' | 'HU' | 'ID' | 'IE' | 'IL' | 'IM' | 'IN' | 'IO' | 'IQ' | 'IS' | 'IT' | 'JE' | 'JM' | 'JO' | 'JP' | 'KE' | 'KG' | 'KH' | 'KI' | 'KM' | 'KN' | 'KR' | 'KW' | 'KY' | 'KZ' | 'LA' | 'LB' | 'LC' | 'LI' | 'LK' | 'LR' | 'LS' | 'LT' | 'LU' | 'LV' | 'LY' | 'MA' | 'MC' | 'MD' | 'ME' | 'MF' | 'MG' | 'MK' | 'ML' | 'MM' | 'MN' | 'MO' | 'MQ' | 'MR' | 'MS' | 'MT' | 'MU' | 'MV' | 'MW' | 'MX' | 'MY' | 'MZ' | 'NA' | 'NC' | 'NE' | 'NG' | 'NI' | 'NL' | 'NO' | 'NP' | 'NR' | 'NU' | 'NZ' | 'OM' | 'PA' | 'PE' | 'PF' | 'PG' | 'PH' | 'PK' | 'PL' | 'PM' | 'PN' | 'PR' | 'PS' | 'PT' | 'PY' | 'QA' | 'RE' | 'RO' | 'RS' | 'RU' | 'RW' | 'SA' | 'SB' | 'SC' | 'SD' | 'SE' | 'SG' | 'SH' | 'SI' | 'SJ' | 'SK' | 'SL' | 'SM' | 'SN' | 'SO' | 'SR' | 'SS' | 'ST' | 'SV' | 'SX' | 'SZ' | 'TA' | 'TC' | 'TD' | 'TF' | 'TG' | 'TH' | 'TJ' | 'TK' | 'TL' | 'TM' | 'TN' | 'TO' | 'TR' | 'TT' | 'TV' | 'TW' | 'TZ' | 'UA' | 'UG' | 'US' | 'UY' | 'UZ' | 'VA' | 'VC' | 'VE' | 'VG' | 'VN' | 'VU' | 'WF' | 'WS' | 'XK' | 'YE' | 'YT' | 'ZA' | 'ZM' | 'ZW' | 'ZZ' | OtherString;
    }
    namespace SubscriptionData {
        interface InvoiceSettings {
            /**
             * The connected account that issues the invoice. The invoice is presented with the branding and support information of the specified account.
             */
            issuer?: InvoiceSettings.Issuer;
        }
        interface TrialSettings {
            /**
             * Defines how the subscription should behave when the user's free trial ends.
             */
            end_behavior: TrialSettings.EndBehavior;
        }
        namespace InvoiceSettings {
            interface Issuer {
                /**
                 * The connected account being referenced when `type` is `account`.
                 */
                account?: string;
                /**
                 * Type of the account referenced in the request.
                 */
                type: Issuer.Type;
            }
            namespace Issuer {
                type Type = 'account' | 'self' | OtherString;
            }
        }
        namespace TrialSettings {
            interface EndBehavior {
                /**
                 * Indicates how the subscription should change when the trial ends if the user did not provide a payment method.
                 */
                missing_payment_method: EndBehavior.MissingPaymentMethod;
            }
            namespace EndBehavior {
                type MissingPaymentMethod = 'cancel' | 'create_invoice' | 'pause' | OtherString;
            }
        }
    }
    namespace TaxIdCollection {
        type Required = 'if_supported' | 'never' | OtherString;
    }
}
export interface PaymentLinkListParams extends PaginationParams {
    /**
     * Only return payment links that are active or inactive (e.g., pass `false` to list all inactive payment links).
     */
    active?: boolean;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
}
export interface PaymentLinkListLineItemsParams extends PaginationParams {
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
}
