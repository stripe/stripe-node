import { StripeResource } from '../../StripeResource.js';
import { Supplier } from './Suppliers.js';
import { PaginationParams, Decimal } from '../../shared.js';
import { RequestOptions, ApiListPromise, Response } from '../../lib.js';
export declare class ProductResource extends StripeResource {
    /**
     * Lists all available Climate product objects.
     */
    list(params?: Climate.ProductListParams, options?: RequestOptions): ApiListPromise<Product>;
    /**
     * Retrieves the details of a Climate product with the given ID.
     */
    retrieve(id: string, params?: Climate.ProductRetrieveParams, options?: RequestOptions): Promise<Response<Product>>;
}
export interface Product {
    /**
     * Unique identifier for the object. For convenience, Climate product IDs are human-readable strings
     * that start with `climsku_`. See [carbon removal inventory](https://stripe.com/docs/climate/orders/carbon-removal-inventory)
     * for a list of available carbon removal products.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'climate.product';
    /**
     * Time at which the object was created. Measured in seconds since the Unix epoch.
     */
    created: number;
    /**
     * Current prices for a metric ton of carbon removal in a currency's smallest unit.
     */
    current_prices_per_metric_ton: {
        [key: string]: Product.CurrentPricesPerMetricTon;
    };
    /**
     * The year in which the carbon removal is expected to be delivered. If the year is in the past, this represents spot inventory with guaranteed delivery.
     */
    delivery_year: number | null;
    /**
     * Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode.
     */
    livemode: boolean;
    /**
     * The quantity of metric tons available for reservation.
     */
    metric_tons_available: Decimal;
    /**
     * The Climate product's name.
     */
    name: string;
    /**
     * The carbon removal suppliers that fulfill orders for this Climate product.
     */
    suppliers: Array<Supplier>;
}
export declare namespace Product {
    interface CurrentPricesPerMetricTon {
        /**
         * Fees for one metric ton of carbon removal in the currency's smallest unit.
         */
        amount_fees: number;
        /**
         * Subtotal for one metric ton of carbon removal (excluding fees) in the currency's smallest unit.
         */
        amount_subtotal: number;
        /**
         * Total for one metric ton of carbon removal (including fees) in the currency's smallest unit.
         */
        amount_total: number;
    }
}
export declare namespace Climate {
    interface ProductRetrieveParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
export declare namespace Climate {
    interface ProductListParams extends PaginationParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
