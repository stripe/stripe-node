import { StripeResource } from '../../StripeResource.js';
import { MetadataParam, OtherString, PaginationParams, RangeQueryParam, Metadata } from '../../shared.js';
import { RequestOptions, ApiListPromise, Response } from '../../lib.js';
export declare class RequestResource extends StripeResource {
    /**
     * Lists all ForwardingRequest objects.
     */
    list(params?: Forwarding.RequestListParams, options?: RequestOptions): ApiListPromise<Request>;
    /**
     * Creates a ForwardingRequest object.
     */
    create(params: Forwarding.RequestCreateParams, options?: RequestOptions): Promise<Response<Request>>;
    /**
     * Retrieves a ForwardingRequest object.
     */
    retrieve(id: string, params?: Forwarding.RequestRetrieveParams, options?: RequestOptions): Promise<Response<Request>>;
}
export interface Request {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'forwarding.request';
    /**
     * Time at which the object was created. Measured in seconds since the Unix epoch.
     */
    created: number;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.
     */
    metadata?: Metadata | null;
    /**
     * The PaymentMethod to insert into the forwarded request. Forwarding previously consumed PaymentMethods is allowed.
     */
    payment_method: string;
    /**
     * The field kinds to be replaced in the forwarded request.
     */
    replacements: Array<Request.Replacement>;
    /**
     * Context about the request from Stripe's servers to the destination endpoint.
     */
    request_context: Request.RequestContext | null;
    /**
     * The request that was sent to the destination endpoint. We redact any sensitive fields.
     */
    request_details: Request.RequestDetails | null;
    /**
     * The response that the destination endpoint returned to us. We redact any sensitive fields.
     */
    response_details: Request.ResponseDetails | null;
    /**
     * The destination URL for the forwarded request. Must be supported by the config.
     */
    url: string | null;
}
export declare namespace Request {
    type Replacement = 'card_cvc' | 'card_expiry' | 'card_number' | 'cardholder_name' | 'request_signature' | OtherString;
    interface RequestContext {
        /**
         * The time it took in milliseconds for the destination endpoint to respond.
         */
        destination_duration: number;
        /**
         * The IP address of the destination.
         */
        destination_ip_address: string;
    }
    interface RequestDetails {
        /**
         * The body payload to send to the destination endpoint.
         */
        body: string;
        /**
         * The headers to include in the forwarded request. Can be omitted if no additional headers (excluding Stripe-generated ones such as the Content-Type header) should be included.
         */
        headers: Array<RequestDetails.Header>;
        /**
         * The HTTP method used to call the destination endpoint.
         */
        http_method: 'POST';
    }
    interface ResponseDetails {
        /**
         * The response body from the destination endpoint to Stripe.
         */
        body: string;
        /**
         * HTTP headers that the destination endpoint returned.
         */
        headers: Array<ResponseDetails.Header>;
        /**
         * The HTTP status code that the destination endpoint returned.
         */
        status: number;
    }
    namespace RequestDetails {
        interface Header {
            /**
             * The header name.
             */
            name: string;
            /**
             * The header value.
             */
            value: string;
        }
    }
    namespace ResponseDetails {
        interface Header {
            /**
             * The header name.
             */
            name: string;
            /**
             * The header value.
             */
            value: string;
        }
    }
}
export declare namespace Forwarding {
    interface RequestCreateParams {
        /**
         * The PaymentMethod to insert into the forwarded request. Forwarding previously consumed PaymentMethods is allowed.
         */
        payment_method: string;
        /**
         * The field kinds to be replaced in the forwarded request.
         */
        replacements: Array<RequestCreateParams.Replacement>;
        /**
         * The request body and headers to be sent to the destination endpoint.
         */
        request: RequestCreateParams.Request;
        /**
         * The destination URL for the forwarded request. Must be supported by the config.
         */
        url: string;
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
         */
        metadata?: MetadataParam;
    }
    namespace RequestCreateParams {
        type Replacement = 'card_cvc' | 'card_expiry' | 'card_number' | 'cardholder_name' | 'request_signature' | OtherString;
        interface Request {
            /**
             * The body payload to send to the destination endpoint.
             */
            body?: string;
            /**
             * The headers to include in the forwarded request. Can be omitted if no additional headers (excluding Stripe-generated ones such as the Content-Type header) should be included.
             */
            headers?: Array<Request.Header>;
        }
        namespace Request {
            interface Header {
                /**
                 * The header name.
                 */
                name: string;
                /**
                 * The header value.
                 */
                value: string;
            }
        }
    }
}
export declare namespace Forwarding {
    interface RequestRetrieveParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
export declare namespace Forwarding {
    interface RequestListParams extends PaginationParams {
        /**
         * Similar to other List endpoints, filters results based on created timestamp. You can pass gt, gte, lt, and lte timestamp values.
         */
        created?: RangeQueryParam;
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
