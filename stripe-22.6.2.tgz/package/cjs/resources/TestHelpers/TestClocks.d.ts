import { StripeResource } from '../../StripeResource.js';
import { PaginationParams, OtherString } from '../../shared.js';
import { RequestOptions, Response, ApiListPromise } from '../../lib.js';
export declare class TestClockResource extends StripeResource {
    /**
     * Deletes a test clock.
     */
    del(id: string, params?: TestHelpers.TestClockDeleteParams, options?: RequestOptions): Promise<Response<DeletedTestClock>>;
    /**
     * Retrieves a test clock.
     */
    retrieve(id: string, params?: TestHelpers.TestClockRetrieveParams, options?: RequestOptions): Promise<Response<TestClock>>;
    /**
     * Returns a list of your test clocks.
     */
    list(params?: TestHelpers.TestClockListParams, options?: RequestOptions): ApiListPromise<TestClock>;
    /**
     * Creates a new test clock that can be attached to new customers and quotes.
     */
    create(params: TestHelpers.TestClockCreateParams, options?: RequestOptions): Promise<Response<TestClock>>;
    /**
     * Starts advancing a test clock to a specified time in the future. Advancement is done when status changes to Ready.
     */
    advance(id: string, params: TestHelpers.TestClockAdvanceParams, options?: RequestOptions): Promise<Response<TestClock>>;
}
export interface TestClock {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'test_helpers.test_clock';
    /**
     * Time at which the object was created. Measured in seconds since the Unix epoch.
     */
    created: number;
    /**
     * Always true for a deleted object
     */
    deleted?: void;
    /**
     * Time at which this clock is scheduled to auto delete.
     */
    deletes_after: number;
    /**
     * Time at which all objects belonging to this clock are frozen.
     */
    frozen_time: number;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * The custom name supplied at creation.
     */
    name: string | null;
    /**
     * The status of the Test Clock.
     */
    status: TestClock.Status;
    status_details: TestClock.StatusDetails;
}
export interface DeletedTestClock {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'test_helpers.test_clock';
    /**
     * Always true for a deleted object
     */
    deleted: true;
}
export declare namespace TestClock {
    type Status = 'advancing' | 'internal_failure' | 'ready' | OtherString;
    interface StatusDetails {
        advancing?: StatusDetails.Advancing;
    }
    namespace StatusDetails {
        interface Advancing {
            /**
             * The `frozen_time` that the Test Clock is advancing towards.
             */
            target_frozen_time: number;
        }
    }
}
export declare namespace TestHelpers {
    interface TestClockCreateParams {
        /**
         * The initial frozen time for this test clock.
         */
        frozen_time: number;
        /**
         * Existing customer this test clock will be attached to. Once attached, customers can't be removed from a test clock.
         */
        customer?: string;
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
        /**
         * The name for this test clock.
         */
        name?: string;
    }
}
export declare namespace TestHelpers {
    interface TestClockRetrieveParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
export declare namespace TestHelpers {
    interface TestClockListParams extends PaginationParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
export declare namespace TestHelpers {
    interface TestClockDeleteParams {
    }
}
export declare namespace TestHelpers {
    interface TestClockAdvanceParams {
        /**
         * The time to advance the test clock. Must be after the test clock's current frozen time. Cannot be more than two intervals in the future from the shortest subscription in this test clock. If there are no subscriptions in this test clock, it cannot be more than two years in the future.
         */
        frozen_time: number;
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
